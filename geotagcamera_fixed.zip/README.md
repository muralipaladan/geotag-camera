# GPS Geotag Camera (Android)

A native Android application built with Kotlin and Jetpack Compose for capturing photos with embedded real-time GPS location coordinates, timestamp, site notes, tags, and a scannable Google Maps QR code.

## Key Features

- **CameraX Integration**: Live camera preview with high-resolution photo capture and front/back lens switching.
- **Real-Time Geolocation**: Live GPS status tracking, location accuracy indicator (± meters), and live clock.
- **Map Inset**: Interactive location map with HYBRID / ROAD layer toggling and expand view.
- **Site Notes & Tagging**: Custom input card for site name, observation remarks, and custom tags (e.g., `KLU Act 2008`).
- **Watermark & QR Stamping**: Automatically stamps photos with gradient overlay, GPS coordinates, date/time, site details, and a scannable QR code linking to Google Maps location.
- **Local Room Persistence**: Reactive photo gallery backed by SQLite Room Database.
- **Photo Viewer & Sharing**: Fullscreen image inspector with Google Maps navigation launcher and native sharing.
