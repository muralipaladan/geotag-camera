package com.example.geotagcamera.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface GeotagDao {
    @Query("SELECT * FROM geotag_photos ORDER BY timestamp DESC")
    fun getAllPhotos(): Flow<List<GeotagPhotoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhoto(photo: GeotagPhotoEntity): Long

    @Query("DELETE FROM geotag_photos WHERE id = :id")
    suspend fun deletePhotoById(id: Long)
}
