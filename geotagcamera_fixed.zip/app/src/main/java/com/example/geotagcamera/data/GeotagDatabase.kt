package com.example.geotagcamera.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [GeotagPhotoEntity::class], version = 1, exportSchema = false)
abstract class GeotagDatabase : RoomDatabase() {
    abstract fun geotagDao(): GeotagDao

    companion object {
        @Volatile
        private var INSTANCE: GeotagDatabase? = null

        fun getDatabase(context: Context): GeotagDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GeotagDatabase::class.java,
                    "geotag_photos_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
