package com.example.geotagcamera.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "geotag_photos")
data class GeotagPhotoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val filePath: String,
    val latitude: Double?,
    val longitude: Double?,
    val accuracy: Float?,
    val siteName: String,
    val note: String,
    val tag: String,
    val mapsUrl: String?,
    val timestamp: Long = System.currentTimeMillis()
)
