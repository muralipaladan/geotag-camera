package com.example.geotagcamera.data

import kotlinx.coroutines.flow.Flow

class GeotagRepository(private val dao: GeotagDao) {
    val allPhotos: Flow<List<GeotagPhotoEntity>> = dao.getAllPhotos()

    suspend fun savePhoto(photo: GeotagPhotoEntity): Long {
        return dao.insertPhoto(photo)
    }

    suspend fun deletePhoto(id: Long) {
        dao.deletePhotoById(id)
    }
}
