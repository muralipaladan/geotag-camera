package com.example.geotagcamera.ui

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.geotagcamera.data.GeotagDatabase
import com.example.geotagcamera.data.GeotagPhotoEntity
import com.example.geotagcamera.data.GeotagRepository
import com.example.geotagcamera.util.GPSData
import com.example.geotagcamera.util.LocationTracker
import com.example.geotagcamera.util.WatermarkStamper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GeotagRepository
    val locationTracker: LocationTracker = LocationTracker(application)

    val photosList: StateFlow<List<GeotagPhotoEntity>>
    val gpsState: StateFlow<GPSData> = locationTracker.gpsState

    // Note input fields
    private val _siteName = MutableStateFlow("")
    val siteName: StateFlow<String> = _siteName.asStateFlow()

    private val _siteNote = MutableStateFlow("")
    val siteNote: StateFlow<String> = _siteNote.asStateFlow()

    private val _siteTag = MutableStateFlow("KLU Act 2008")
    val siteTag: StateFlow<String> = _siteTag.asStateFlow()

    private val _isNotePanelOpen = MutableStateFlow(false)
    val isNotePanelOpen: StateFlow<Boolean> = _isNotePanelOpen.asStateFlow()

    // Camera Lens State
    private val _isFrontCamera = MutableStateFlow(false)
    val isFrontCamera: StateFlow<Boolean> = _isFrontCamera.asStateFlow()

    // Map expanded state
    private val _isMapExpanded = MutableStateFlow(false)
    val isMapExpanded: StateFlow<Boolean> = _isMapExpanded.asStateFlow()

    private val _isHybridMap = MutableStateFlow(true)
    val isHybridMap: StateFlow<Boolean> = _isHybridMap.asStateFlow()

    // Capture Confirm Dialog
    private val _pendingStampedBitmap = MutableStateFlow<Bitmap?>(null)
    val pendingStampedBitmap: StateFlow<Bitmap?> = _pendingStampedBitmap.asStateFlow()

    private val _isConfirmModalOpen = MutableStateFlow(false)
    val isConfirmModalOpen: StateFlow<Boolean> = _isConfirmModalOpen.asStateFlow()

    // Gallery and Photo Viewer
    private val _isGalleryOpen = MutableStateFlow(false)
    val isGalleryOpen: StateFlow<Boolean> = _isGalleryOpen.asStateFlow()

    private val _viewingPhoto = MutableStateFlow<GeotagPhotoEntity?>(null)
    val viewingPhoto: StateFlow<GeotagPhotoEntity?> = _viewingPhoto.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    init {
        val db = GeotagDatabase.getDatabase(application)
        repository = GeotagRepository(db.geotagDao())
        photosList = repository.allPhotos.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun startLocationUpdates() {
        locationTracker.startTracking()
    }

    fun stopLocationUpdates() {
        locationTracker.stopTracking()
    }

    fun toggleCameraLens() {
        _isFrontCamera.value = !_isFrontCamera.value
        showToast(if (_isFrontCamera.value) "മുൻ ക്യാമറ തിരഞ്ഞെടുത്തു" else "പിൻ ക്യാമറ തിരഞ്ഞെടുത്തു")
    }

    fun toggleNotePanel() {
        _isNotePanelOpen.value = !_isNotePanelOpen.value
    }

    fun updateSiteName(name: String) {
        _siteName.value = name
    }

    fun updateSiteNote(note: String) {
        _siteNote.value = note
    }

    fun updateSiteTag(tag: String) {
        _siteTag.value = tag
    }

    fun clearNotes() {
        _siteName.value = ""
        _siteNote.value = ""
        _siteTag.value = ""
    }

    fun saveNotes() {
        _isNotePanelOpen.value = false
        showToast("കുറിപ്പ് സേവ് ചെയ്തു")
    }

    fun toggleMapExpanded() {
        _isMapExpanded.value = !_isMapExpanded.value
    }

    fun toggleMapHybrid() {
        _isHybridMap.value = !_isHybridMap.value
    }

    fun processCapturedPhoto(originalBitmap: Bitmap) {
        viewModelScope.launch {
            val gps = gpsState.value
            val timeStr = getFormattedDateTime()
            val stamped = WatermarkStamper.stampImage(
                original = originalBitmap,
                latitude = gps.latitude,
                longitude = gps.longitude,
                dateTimeStr = timeStr,
                siteName = _siteName.value,
                note = _siteNote.value,
                tag = _siteTag.value
            )
            _pendingStampedBitmap.value = stamped
            _isConfirmModalOpen.value = true
        }
    }

    fun discardPendingPhoto() {
        _pendingStampedBitmap.value = null
        _isConfirmModalOpen.value = false
    }

    fun savePendingPhoto() {
        val bitmap = _pendingStampedBitmap.value ?: return
        viewModelScope.launch {
            try {
                val context = getApplication<Application>().applicationContext
                val filename = "geotag_${System.currentTimeMillis()}.jpg"
                val photoFile = File(context.filesDir, filename)
                val fos = FileOutputStream(photoFile)
                bitmap.compress(Bitmap.CompressFormat.JPEG, 92, fos)
                fos.flush()
                fos.close()

                val gps = gpsState.value
                val mapsUrl = if (gps.latitude != null && gps.longitude != null) {
                    "https://www.google.com/maps?q=${gps.latitude},${gps.longitude}"
                } else null

                val photoEntity = GeotagPhotoEntity(
                    filePath = photoFile.absolutePath,
                    latitude = gps.latitude,
                    longitude = gps.longitude,
                    accuracy = gps.accuracy,
                    siteName = _siteName.value,
                    note = _siteNote.value,
                    tag = _siteTag.value,
                    mapsUrl = mapsUrl
                )

                repository.savePhoto(photoEntity)
                showToast("ഫോട്ടോ സേവ് ചെയ്തു ✓")
            } catch (e: Exception) {
                e.printStackTrace()
                showToast("സേവ് ചെയ്യുന്നതിൽ പിഴവ്")
            } finally {
                _pendingStampedBitmap.value = null
                _isConfirmModalOpen.value = false
            }
        }
    }

    fun openGallery() {
        _isGalleryOpen.value = true
    }

    fun closeGallery() {
        _isGalleryOpen.value = false
    }

    fun openPhotoViewer(photo: GeotagPhotoEntity) {
        _viewingPhoto.value = photo
    }

    fun closePhotoViewer() {
        _viewingPhoto.value = null
    }

    fun deletePhoto(photo: GeotagPhotoEntity) {
        viewModelScope.launch {
            try {
                val file = File(photo.filePath)
                if (file.exists()) {
                    file.delete()
                }
                repository.deletePhoto(photo.id)
                closePhotoViewer()
                showToast("ഫോട്ടോ നീക്കം ചെയ്തു")
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun getFormattedDateTime(): String {
        val sdf = SimpleDateFormat("dd-MMM-yyyy  hh:mm:ss a", Locale.ENGLISH)
        return sdf.format(Date())
    }
}
