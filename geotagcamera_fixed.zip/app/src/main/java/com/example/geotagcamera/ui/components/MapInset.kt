package com.example.geotagcamera.ui.components

import android.util.Log
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.geotagcamera.ui.theme.Amber
import com.example.geotagcamera.ui.theme.AmberDim
import com.example.geotagcamera.ui.theme.Ink
import com.example.geotagcamera.ui.theme.LineBorder
import com.example.geotagcamera.ui.theme.OkGreen
import com.example.geotagcamera.ui.theme.WarnRed
import com.example.geotagcamera.util.GPSData

@Composable
fun MapInset(
    gpsData: GPSData,
    isExpanded: Boolean,
    isHybrid: Boolean,
    onToggleExpand: () -> Unit,
    onToggleHybrid: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cardWidth = if (isExpanded) 280.dp else 132.dp
    val cardHeight = if (isExpanded) 220.dp else 132.dp

    val accuracy = gpsData.accuracy ?: 30f
    val accColor = when {
        accuracy <= 15f -> OkGreen
        accuracy <= 40f -> Amber
        else -> WarnRed
    }

    var lastLoadedLocation by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var lastHybridState by remember { mutableStateOf<Boolean?>(null) }

    Box(
        modifier = modifier
            .size(cardWidth, cardHeight)
            .animateContentSize()
            .clip(RoundedCornerShape(12.dp))
            .background(Ink)
            .border(2.dp, AmberDim, RoundedCornerShape(12.dp))
            .clickable { onToggleExpand() }
    ) {
        val lat = gpsData.latitude
        val lng = gpsData.longitude

        if (lat != null && lng != null) {
            val tileUrl = if (isHybrid) {
                "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
            } else {
                "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            }

            val htmlContent = """
                <!DOCTYPE html>
                <html>
                <head>
                    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
                    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
                    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
                    <style>
                        html, body, #map { margin: 0; padding: 0; width: 100%; height: 100%; background: #181C20; }
                        .leaflet-control-container { display: none !important; }
                    </style>
                </head>
                <body>
                    <div id="map"></div>
                    <script>
                        var map = L.map('map', { zoomControl: false, attributionControl: false }).setView([$lat, $lng], 17);
                        L.tileLayer('$tileUrl', { maxZoom: 19 }).addTo(map);
                        L.circle([$lat, $lng], {
                            color: '#E0A800',
                            fillColor: '#E0A800',
                            fillOpacity: 0.25,
                            radius: ${accuracy.coerceAtLeast(10f)}
                        }).addTo(map);
                        L.circleMarker([$lat, $lng], {
                            color: '#FFFFFF',
                            fillColor: '#D9383A',
                            fillOpacity: 1,
                            radius: 7,
                            weight: 2
                        }).addTo(map);
                    </script>
                </body>
                </html>
            """.trimIndent()

            AndroidView(
                factory = { context ->
                    WebView(context).apply {
                        webViewClient = object : WebViewClient() {
                            override fun onReceivedError(
                                view: WebView?,
                                request: WebResourceRequest?,
                                error: WebResourceError?
                            ) {
                                super.onReceivedError(view, request, error)
                                Log.e(
                                    "MapInset",
                                    "WebView load failed: ${request?.url} -> ${error?.description}"
                                )
                            }
                        }
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        loadDataWithBaseURL("https://unpkg.com", htmlContent, "text/html", "UTF-8", null)
                        lastLoadedLocation = Pair(lat, lng)
                        lastHybridState = isHybrid
                    }
                },
                update = { webView ->
                    val currentLocation = Pair(lat, lng)
                    if (lastLoadedLocation != currentLocation || lastHybridState != isHybrid) {
                        webView.loadDataWithBaseURL("https://unpkg.com", htmlContent, "text/html", "UTF-8", null)
                        lastLoadedLocation = currentLocation
                        lastHybridState = isHybrid
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val center = Offset(w / 2f, h / 2f)

                val bg = if (isHybrid) Color(0xFF1B2318) else Color(0xFF181C20)
                drawRect(bg)

                val step = 32f
                var x = step
                while (x < w) {
                    drawLine(
                        color = Color(0x332A2E22),
                        start = Offset(x, 0f),
                        end = Offset(x, h),
                        strokeWidth = 1f
                    )
                    x += step
                }
                var y = step
                while (y < h) {
                    drawLine(
                        color = Color(0x332A2E22),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f
                    )
                    y += step
                }

                val radiusPx = (accuracy * 2f).coerceIn(20f, w * 0.45f)
                drawCircle(
                    color = Amber,
                    radius = radiusPx,
                    center = center,
                    style = Stroke(width = 2f)
                )
                drawCircle(
                    color = Amber.copy(alpha = 0.15f),
                    radius = radiusPx,
                    center = center
                )

                drawCircle(
                    color = Amber,
                    radius = 7f,
                    center = center
                )
                drawCircle(
                    color = Color.White,
                    radius = 3f,
                    center = center
                )
            }

            if (gpsData.errorMessage != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = gpsData.errorMessage,
                        color = WarnRed,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(4.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Ink.copy(alpha = 0.85f))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(
                text = "±${accuracy.toInt()}m",
                color = accColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(4.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Ink.copy(alpha = 0.85f))
                .border(1.dp, LineBorder, RoundedCornerShape(6.dp))
                .clickable { onToggleHybrid() }
                .padding(horizontal = 6.dp, vertical = 3.dp)
        ) {
            Text(
                text = if (isHybrid) "HYBRID" else "ROAD",
                color = Amber,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }

        if (isExpanded) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(6.dp)
                    .background(Ink.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                    .padding(4.dp)
            ) {
                if (gpsData.latitude != null && gpsData.longitude != null) {
                    Text(
                        text = String.format("%.5f, %.5f", gpsData.latitude, gpsData.longitude),
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
