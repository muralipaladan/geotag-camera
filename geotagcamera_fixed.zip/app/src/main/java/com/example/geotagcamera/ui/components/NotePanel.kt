package com.example.geotagcamera.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.geotagcamera.ui.theme.Amber
import com.example.geotagcamera.ui.theme.Ink
import com.example.geotagcamera.ui.theme.LineBorder
import com.example.geotagcamera.ui.theme.Paper
import com.example.geotagcamera.ui.theme.PaperDim

@Composable
fun NotePanel(
    siteName: String,
    siteNote: String,
    siteTag: String,
    onSiteNameChange: (String) -> Unit,
    onSiteNoteChange: (String) -> Unit,
    onSiteTagChange: (String) -> Unit,
    onClear: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Ink.copy(alpha = 0.92f))
            .border(1.dp, LineBorder, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Text(
            text = "സ്ഥലത്തിന്റെ പേര് / Site Name",
            color = PaperDim,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = siteName,
            onValueChange = onSiteNameChange,
            placeholder = { Text("ഉദാ: കളിക്കാവ് കോളനി റോഡ്", color = PaperDim.copy(alpha = 0.6f), fontSize = 13.sp) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF0E100C),
                unfocusedContainerColor = Color(0xFF0E100C),
                focusedBorderColor = Amber,
                unfocusedBorderColor = LineBorder,
                focusedTextColor = Paper,
                unfocusedTextColor = Paper
            )
        )

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "കുറിപ്പ് / Remarks",
            color = PaperDim,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = siteNote,
            onValueChange = onSiteNoteChange,
            placeholder = { Text("നിരീക്ഷണം എഴുതുക...", color = PaperDim.copy(alpha = 0.6f), fontSize = 13.sp) },
            minLines = 2,
            maxLines = 3,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF0E100C),
                unfocusedContainerColor = Color(0xFF0E100C),
                focusedBorderColor = Amber,
                unfocusedBorderColor = LineBorder,
                focusedTextColor = Paper,
                unfocusedTextColor = Paper
            )
        )

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "വിഭാഗം / Tag",
            color = PaperDim,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = siteTag,
            onValueChange = onSiteTagChange,
            placeholder = { Text("ഉദാ: KLU Act 2008", color = PaperDim.copy(alpha = 0.6f), fontSize = 13.sp) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF0E100C),
                unfocusedContainerColor = Color(0xFF0E100C),
                focusedBorderColor = Amber,
                unfocusedBorderColor = LineBorder,
                focusedTextColor = Paper,
                unfocusedTextColor = Paper
            )
        )

        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = onClear,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = PaperDim),
                border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("മായ്ക്കുക", fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.padding(horizontal = 4.dp))
            Button(
                onClick = onDone,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Amber,
                    contentColor = Color(0xFF1A1200)
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("ശരി", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
