package com.example.geotagcamera.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.geotagcamera.ui.theme.Amber
import com.example.geotagcamera.ui.theme.Ink
import com.example.geotagcamera.ui.theme.PaperDim

@Composable
fun PermissionScreen(
    onRequestPermissions: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Ink)
            .padding(30.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "ലൊക്കേഷൻ അനുമതി വേണം",
            color = Amber,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "GPS geotag സ്റ്റാമ്പ് ചെയ്യുന്നതിനും accurate location പരിശോധിക്കുന്നതിനും ലൊക്കേഷൻ ആക്‌സസ് ചെയ്യേണ്ടതുണ്ട്.",
            color = PaperDim,
            fontSize = 13.5.sp,
            lineHeight = 22.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(max = 320.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onRequestPermissions,
            colors = ButtonDefaults.buttonColors(
                containerColor = Amber,
                contentColor = Color(0xFF1A1200)
            ),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = "അനുവദിക്കുക",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
