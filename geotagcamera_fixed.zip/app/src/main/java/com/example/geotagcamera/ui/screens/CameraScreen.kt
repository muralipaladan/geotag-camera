package com.example.geotagcamera.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.geotagcamera.ui.MainViewModel
import com.example.geotagcamera.ui.components.GalleryModal
import com.example.geotagcamera.ui.components.MapInset
import com.example.geotagcamera.ui.components.NotePanel
import com.example.geotagcamera.ui.components.PhotoViewer
import com.example.geotagcamera.ui.theme.Amber
import com.example.geotagcamera.ui.theme.Ink
import com.example.geotagcamera.ui.theme.LineBorder
import com.example.geotagcamera.ui.theme.OkGreen
import com.example.geotagcamera.ui.theme.Paper
import com.example.geotagcamera.ui.theme.PaperDim
import com.example.geotagcamera.ui.theme.WarnRed
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CameraScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val gpsState by viewModel.gpsState.collectAsState()
    val photosList by viewModel.photosList.collectAsState()

    val siteName by viewModel.siteName.collectAsState()
    val siteNote by viewModel.siteNote.collectAsState()
    val siteTag by viewModel.siteTag.collectAsState()
    val isNotePanelOpen by viewModel.isNotePanelOpen.collectAsState()

    val isFrontCamera by viewModel.isFrontCamera.collectAsState()
    val isMapExpanded by viewModel.isMapExpanded.collectAsState()
    val isHybridMap by viewModel.isHybridMap.collectAsState()

    val pendingStampedBitmap by viewModel.pendingStampedBitmap.collectAsState()
    val isConfirmModalOpen by viewModel.isConfirmModalOpen.collectAsState()

    val isGalleryOpen by viewModel.isGalleryOpen.collectAsState()
    val viewingPhoto by viewModel.viewingPhoto.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }
    var isCapturing by remember { mutableStateOf(false) }

    var liveClockText by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val sdf = SimpleDateFormat("hh:mm:ss a", Locale.ENGLISH)
        while (true) {
            liveClockText = sdf.format(Date())
            delay(1000)
        }
    }

    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            delay(2000)
            viewModel.clearToast()
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Ink)) {

        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx)
                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }
                    val cap = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                        .build()
                    imageCapture = cap

                    val cameraSelector = if (isFrontCamera) {
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    } else {
                        CameraSelector.DEFAULT_BACK_CAMERA
                    }

                    try {
                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            cameraSelector,
                            preview,
                            cap
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, ContextCompat.getMainExecutor(ctx))
                previewView
            },
            update = { previewView ->
                val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }
                    val cap = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                        .build()
                    imageCapture = cap

                    val cameraSelector = if (isFrontCamera) {
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    } else {
                        CameraSelector.DEFAULT_BACK_CAMERA
                    }

                    try {
                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            cameraSelector,
                            preview,
                            cap
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, ContextCompat.getMainExecutor(context))
            },
            modifier = Modifier.fillMaxSize()
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, start = 12.dp, end = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            val dotColor = when {
                gpsState.isSearching -> WarnRed
                (gpsState.accuracy ?: 100f) <= 15f -> OkGreen
                (gpsState.accuracy ?: 100f) <= 40f -> Amber
                else -> WarnRed
            }
            val gpsText = if (gpsState.isSearching) {
                "GPS തിരയുന്നു..."
            } else {
                "±${gpsState.accuracy?.toInt() ?: "--"}m accuracy"
            }

            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Ink.copy(alpha = 0.75f))
                    .border(1.dp, LineBorder, CircleShape)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(dotColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = gpsText, color = Paper, fontSize = 12.5.sp)
                }
            }

            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Ink.copy(alpha = 0.75f))
                    .border(1.dp, LineBorder, CircleShape)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(text = liveClockText, color = Paper, fontSize = 12.5.sp)
            }
        }

        MapInset(
            gpsData = gpsState,
            isExpanded = isMapExpanded,
            isHybrid = isHybridMap,
            onToggleExpand = { viewModel.toggleMapExpanded() },
            onToggleHybrid = { viewModel.toggleMapHybrid() },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 58.dp, end = 12.dp)
        )

        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(top = 58.dp, start = 12.dp)
                .clip(CircleShape)
                .background(Ink.copy(alpha = 0.75f))
                .border(1.dp, LineBorder, CircleShape)
                .clickable { viewModel.toggleNotePanel() }
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(text = "📝 കുറിപ്പ്", color = Paper, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }

        AnimatedVisibility(
            visible = isNotePanelOpen,
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically(),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(top = 104.dp, start = 12.dp, end = 12.dp)
        ) {
            NotePanel(
                siteName = siteName,
                siteNote = siteNote,
                siteTag = siteTag,
                onSiteNameChange = { viewModel.updateSiteName(it) },
                onSiteNoteChange = { viewModel.updateSiteNote(it) },
                onSiteTagChange = { viewModel.updateSiteTag(it) },
                onClear = { viewModel.clearNotes() },
                onDone = { viewModel.saveNotes() }
            )
        }

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 110.dp)
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                    )
                )
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Column {
                val coords = if (gpsState.latitude != null && gpsState.longitude != null) {
                    String.format("%.6f° N, %.6f° E", gpsState.latitude, gpsState.longitude)
                } else {
                    "-- , --"
                }
                Text(text = coords, color = Amber, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                Text(text = "Date & Time: ${viewModel.getFormattedDateTime()}", color = Color(0xFFF2F2EA), fontSize = 11.5.sp)
                Text(text = if (siteName.isNotBlank()) siteName else "Unassigned Site", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                if (siteNote.isNotBlank()) {
                    Text(text = siteNote, color = PaperDim, fontSize = 11.sp)
                }
                if (siteTag.isNotBlank()) {
                    Text(text = siteTag, color = Color(0xFF5FB8D9), fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Ink.copy(alpha = 0.9f))
                .border(1.dp, LineBorder)
                .padding(horizontal = 28.dp, vertical = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.06f))
                            .border(1.dp, LineBorder, CircleShape)
                            .clickable { viewModel.openGallery() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = "Gallery",
                            tint = Paper,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    if (photosList.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .clip(CircleShape)
                                .background(Amber)
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = if (photosList.size > 99) "99+" else photosList.size.toString(),
                                color = Color(0xFF1A1200),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(Color.White, Color(0xFFD8D8D0))
                            )
                        )
                        .border(4.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                        .clickable(enabled = !isCapturing) {
                            val cap = imageCapture ?: return@clickable
                            isCapturing = true
                            cap.takePicture(
                                ContextCompat.getMainExecutor(context),
                                object : ImageCapture.OnImageCapturedCallback() {
                                    override fun onCaptureSuccess(image: ImageProxy) {
                                        try {
                                            val buffer = image.planes[0].buffer
                                            val bytes = ByteArray(buffer.remaining())
                                            buffer.get(bytes)
                                            var bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                            val rotation = image.imageInfo.rotationDegrees
                                            if (rotation != 0) {
                                                val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
                                                bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                                            }
                                            viewModel.processCapturedPhoto(bitmap)
                                        } catch (e: Exception) {
                                            e.printStackTrace()
                                            viewModel.showToast("ഫോട്ടോ പ്രോസസ് ചെയ്യുന്നതിൽ പിഴവ്")
                                        } finally {
                                            image.close()
                                            isCapturing = false
                                        }
                                    }

                                    override fun onError(exception: ImageCaptureException) {
                                        exception.printStackTrace()
                                        viewModel.showToast("ഫോട്ടോ എടുക്കാൻ സാധിച്ചില്ല")
                                        isCapturing = false
                                    }
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (isCapturing) {
                        Text("...", color = Ink, fontWeight = FontWeight.Bold)
                    }
                }

                Box {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.06f))
                            .border(1.dp, LineBorder, CircleShape)
                            .clickable { viewModel.toggleCameraLens() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.FlipCameraAndroid,
                            contentDescription = "Flip Camera",
                            tint = Paper,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Ink)
                            .border(1.dp, LineBorder, RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = if (isFrontCamera) "FRONT" else "BACK",
                            color = PaperDim,
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        if (isConfirmModalOpen && pendingStampedBitmap != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.96f))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    AsyncImage(
                        model = pendingStampedBitmap,
                        contentDescription = "Stamped Preview",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, LineBorder, RoundedCornerShape(8.dp))
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.discardPendingPhoto() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Paper),
                            border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder)
                        ) {
                            Text("ഒഴിവാക്കുക", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.savePendingPhoto() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Amber,
                                contentColor = Color(0xFF1A1200)
                            )
                        ) {
                            Text("സേവ് ചെയ്യുക", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (isGalleryOpen) {
            GalleryModal(
                photos = photosList,
                onSelectPhoto = { viewModel.openPhotoViewer(it) },
                onClose = { viewModel.closeGallery() }
            )
        }

        if (viewingPhoto != null) {
            PhotoViewer(
                photo = viewingPhoto!!,
                onDelete = { viewModel.deletePhoto(it) },
                onClose = { viewModel.closePhotoViewer() }
            )
        }

        if (toastMessage != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 110.dp)
                    .clip(CircleShape)
                    .background(Paper)
                    .padding(horizontal = 16.dp, vertical = 9.dp)
            ) {
                Text(
                    text = toastMessage!!,
                    color = Color(0xFF111111),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
