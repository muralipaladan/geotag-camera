package com.example.geotagcamera.ui.theme

import androidx.compose.ui.graphics.Color

val Amber = Color(0xFFE8952C)
val AmberDim = Color(0xFFA56A1F)
val Ink = Color(0xFF0B0D0A)
val Panel = Color(0xFF12140F)
val Paper = Color(0xFFEEF0E6)
val PaperDim = Color(0xFF9AA08C)
val OkGreen = Color(0xFF4CAF7D)
val WarnRed = Color(0xFFD9553C)
val LineBorder = Color(0xFF2A2E22)
val InfoBlue = Color(0xFF5FB8D9)
