package com.example.geotagcamera.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = Amber,
    onPrimary = Ink,
    primaryContainer = AmberDim,
    onPrimaryContainer = Paper,
    secondary = InfoBlue,
    background = Ink,
    onBackground = Paper,
    surface = Panel,
    onSurface = Paper,
    outline = LineBorder,
    error = WarnRed
)

@Composable
fun GeotagCameraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
