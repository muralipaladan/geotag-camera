package com.example.geotagcamera.util

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Looper
import android.util.Log
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

private const val TAG = "LocationTracker"

data class GPSData(
    val latitude: Double? = null,
    val longitude: Double? = null,
    val accuracy: Float? = null,
    val isSearching: Boolean = true,
    val errorMessage: String? = null
)

class LocationTracker(context: Context) {

    private val appContext: Context = context.applicationContext

    private val fusedLocationClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(appContext)

    private val _gpsState = MutableStateFlow(GPSData())
    val gpsState: StateFlow<GPSData> = _gpsState

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult) {
            val location: Location? = locationResult.lastLocation
            if (location != null) {
                _gpsState.value = GPSData(
                    latitude = location.latitude,
                    longitude = location.longitude,
                    accuracy = location.accuracy,
                    isSearching = false,
                    errorMessage = null
                )
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun startTracking() {
        // 1) Google Play Services ഇല്ലാത്ത/പഴയ device/emulator ആണെങ്കിൽ ഇവിടെ തന്നെ പിടിക്കാം
        val availability = GoogleApiAvailability.getInstance()
        val playServicesStatus = availability.isGooglePlayServicesAvailable(appContext)
        if (playServicesStatus != ConnectionResult.SUCCESS) {
            Log.e(TAG, "Google Play Services unavailable, code=$playServicesStatus")
            _gpsState.value = GPSData(
                isSearching = false,
                errorMessage = "Google Play Services ലഭ്യമല്ല (code $playServicesStatus). GPS map ഈ device-ൽ പ്രവർത്തിക്കില്ല."
            )
            return
        }

        // 2) Device-ന്റെ Location toggle തന്നെ off ആണോ എന്ന് നോക്കാം
        val locationManager = appContext.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        val gpsEnabled = locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true
        val networkEnabled = locationManager?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true
        if (!gpsEnabled && !networkEnabled) {
            Log.e(TAG, "Location services disabled on device")
            _gpsState.value = GPSData(
                isSearching = false,
                errorMessage = "Location (GPS) device-ൽ ഓഫ് ആണ്. Settings-ൽ ഓണ്‍ ചെയ്യൂ."
            )
            return
        }

        val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 2000L)
            .setMinUpdateIntervalMillis(1000L)
            .build()

        try {
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            )
            fusedLocationClient.lastLocation
                .addOnSuccessListener { loc ->
                    if (loc != null) {
                        _gpsState.value = GPSData(
                            latitude = loc.latitude,
                            longitude = loc.longitude,
                            accuracy = loc.accuracy,
                            isSearching = false
                        )
                    }
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "getLastLocation failed", e)
                    _gpsState.value = _gpsState.value.copy(
                        isSearching = false,
                        errorMessage = "Location ലഭിക്കുന്നതിൽ പിഴവ്: ${e.message}"
                    )
                }
        } catch (e: Exception) {
            Log.e(TAG, "startTracking failed", e)
            _gpsState.value = _gpsState.value.copy(
                isSearching = false,
                errorMessage = "GPS start ചെയ്യുന്നതിൽ പിഴവ്: ${e.message}"
            )
        }
    }

    fun stopTracking() {
        try {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
