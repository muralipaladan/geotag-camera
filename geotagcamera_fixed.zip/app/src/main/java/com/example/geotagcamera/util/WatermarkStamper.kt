package com.example.geotagcamera.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

object WatermarkStamper {

    fun stampImage(
        original: Bitmap,
        latitude: Double?,
        longitude: Double?,
        dateTimeStr: String,
        siteName: String,
        note: String,
        tag: String
    ): Bitmap {
        val width = original.width
        val height = original.height

        val workingBitmap = original.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(workingBitmap)

        val padding = (width * 0.035f)
        val barHeight = (height * 0.18f)

        // Gradient overlay at bottom
        val gradPaint = Paint().apply {
            shader = LinearGradient(
                0f, height - barHeight, 0f, height.toFloat(),
                Color.TRANSPARENT, Color.argb(200, 0, 0, 0),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, height - barHeight, width.toFloat(), height.toFloat(), gradPaint)

        val qrSize = (width * 0.16f).toInt()
        val baseSize = maxOf(18f, width * 0.028f)
        var y = height - barHeight + baseSize * 1.3f

        // 1. Coordinates
        val coordText = if (latitude != null && longitude != null) {
            String.format("%.6f° N, %.6f° E", latitude, longitude)
        } else {
            "GPS unavailable"
        }
        val coordPaint = Paint().apply {
            color = Color.parseColor("#E8952C")
            textSize = baseSize * 1.15f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText(coordText, padding, y, coordPaint)
        y += baseSize * 1.4f

        // 2. Date & Time
        val datePaint = Paint().apply {
            color = Color.parseColor("#F2F2EA")
            textSize = baseSize * 0.75f
            isAntiAlias = true
        }
        canvas.drawText("Date & Time: $dateTimeStr", padding, y, datePaint)
        y += baseSize * 1.15f

        // 3. Site Name
        val sitePaint = Paint().apply {
            color = Color.WHITE
            textSize = baseSize * 0.85f
            isFakeBoldText = true
            isAntiAlias = true
        }
        val siteDisplay = if (siteName.isNotBlank()) siteName else "Unassigned Site"
        canvas.drawText(siteDisplay, padding, y, sitePaint)
        y += baseSize * 1.0f

        // 4. Note / Remarks
        if (note.isNotBlank()) {
            val notePaint = Paint().apply {
                color = Color.parseColor("#B9BFA9")
                textSize = baseSize * 0.65f
                isAntiAlias = true
            }
            val shortNote = if (note.length > 60) note.take(60) + "..." else note
            canvas.drawText(shortNote, padding, y, notePaint)
            y += baseSize * 0.9f
        }

        // 5. Tag
        if (tag.isNotBlank()) {
            val tagPaint = Paint().apply {
                color = Color.parseColor("#5FB8D9")
                textSize = baseSize * 0.6f
                isFakeBoldText = true
                isAntiAlias = true
            }
            canvas.drawText(tag, padding, y, tagPaint)
        }

        // 6. QR Code
        val mapsUrl = if (latitude != null && longitude != null) {
            "https://www.google.com/maps?q=$latitude,$longitude"
        } else null

        if (mapsUrl != null && qrSize > 0) {
            try {
                val qrBitmap = generateQRCode(mapsUrl, qrSize)
                if (qrBitmap != null) {
                    val qrX = width - padding - qrSize
                    val qrY = height - barHeight + (barHeight - qrSize) * 0.25f

                    // White background plate
                    val bgPaint = Paint().apply { color = Color.WHITE }
                    val rect = RectF(qrX - 4, qrY - 4, qrX + qrSize + 4, qrY + qrSize + 4)
                    canvas.drawRoundRect(rect, 8f, 8f, bgPaint)

                    canvas.drawBitmap(qrBitmap, qrX, qrY, null)

                    val labelPaint = Paint().apply {
                        color = Color.parseColor("#DCDED4")
                        textSize = maxOf(10f, baseSize * 0.42f)
                        isFakeBoldText = true
                        textAlign = Paint.Align.CENTER
                        isAntiAlias = true
                    }
                    canvas.drawText("GPS MAP QR", qrX + qrSize / 2f, qrY + qrSize + baseSize * 0.55f, labelPaint)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        return workingBitmap
    }

    private fun generateQRCode(text: String, size: Int): Bitmap? {
        return try {
            val writer = QRCodeWriter()
            val bitMatrix = writer.encode(text, BarcodeFormat.QR_CODE, size, size)
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            for (x in 0 until size) {
                for (y in 0 until size) {
                    bmp.setPixel(x, y, if (bitMatrix[x, y]) Color.BLACK else Color.WHITE)
                }
            }
            bmp
        } catch (e: Exception) {
            null
        }
    }
}
