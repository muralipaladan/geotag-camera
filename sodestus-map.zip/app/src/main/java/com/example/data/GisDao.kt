package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface GisDao {
    // WMS Layers Queries
    @Query("SELECT * FROM wms_layers ORDER BY timestamp DESC")
    fun getAllWmsLayers(): Flow<List<WmsLayer>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWmsLayer(layer: WmsLayer): Long

    @Update
    suspend fun updateWmsLayer(layer: WmsLayer)

    @Delete
    suspend fun deleteWmsLayer(layer: WmsLayer)

    @Query("DELETE FROM wms_layers WHERE id = :id")
    suspend fun deleteWmsLayerById(id: Long)

    // GIS Features Queries (Waypoints, Lines, Polygons)
    @Query("SELECT * FROM gis_features ORDER BY timestamp DESC")
    fun getAllGisFeatures(): Flow<List<GisFeature>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGisFeature(feature: GisFeature): Long

    @Update
    suspend fun updateGisFeature(feature: GisFeature)

    @Delete
    suspend fun deleteGisFeature(feature: GisFeature)

    @Query("DELETE FROM gis_features WHERE id = :id")
    suspend fun deleteGisFeatureById(id: Long)

    @Query("DELETE FROM gis_features")
    suspend fun deleteAllGisFeatures()
}
