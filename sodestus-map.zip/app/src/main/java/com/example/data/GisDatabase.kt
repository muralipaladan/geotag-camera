package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [WmsLayer::class, GisFeature::class],
    version = 1,
    exportSchema = false
)
abstract class GisDatabase : RoomDatabase() {
    abstract fun gisDao(): GisDao

    companion object {
        @Volatile
        private var INSTANCE: GisDatabase? = null

        fun getDatabase(context: Context): GisDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GisDatabase::class.java,
                    "gis_map_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
