package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class FeatureType {
    WAYPOINT,
    LINE,
    POLYGON
}

@Entity(tableName = "gis_features")
data class GisFeature(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val featureType: FeatureType,
    val pointsJson: String, // JSON array of [{"lat": 10.0, "lon": 76.0}]
    val colorHex: String = "#FF2196F3",
    val strokeWidthDp: Float = 3.0f,
    val fillAlpha: Float = 0.3f,
    val lengthMeters: Double = 0.0,
    val areaSqMeters: Double = 0.0,
    val category: String = "General",
    val timestamp: Long = System.currentTimeMillis()
)
