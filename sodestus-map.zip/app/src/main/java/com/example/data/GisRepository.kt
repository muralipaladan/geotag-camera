package com.example.data

import kotlinx.coroutines.flow.Flow

class GisRepository(private val gisDao: GisDao) {
    val allWmsLayers: Flow<List<WmsLayer>> = gisDao.getAllWmsLayers()
    val allGisFeatures: Flow<List<GisFeature>> = gisDao.getAllGisFeatures()

    suspend fun insertWmsLayer(layer: WmsLayer): Long = gisDao.insertWmsLayer(layer)
    suspend fun updateWmsLayer(layer: WmsLayer) = gisDao.updateWmsLayer(layer)
    suspend fun deleteWmsLayer(layer: WmsLayer) = gisDao.deleteWmsLayer(layer)
    suspend fun deleteWmsLayerById(id: Long) = gisDao.deleteWmsLayerById(id)

    suspend fun insertGisFeature(feature: GisFeature): Long = gisDao.insertGisFeature(feature)
    suspend fun updateGisFeature(feature: GisFeature) = gisDao.updateGisFeature(feature)
    suspend fun deleteGisFeature(feature: GisFeature) = gisDao.deleteGisFeature(feature)
    suspend fun deleteGisFeatureById(id: Long) = gisDao.deleteGisFeatureById(id)
    suspend fun deleteAllGisFeatures() = gisDao.deleteAllGisFeatures()
}
