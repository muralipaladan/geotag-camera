package com.example.data

object SampleWmsServers {
    val presets = listOf(
        WmsLayer(
            name = "9400849115",
            serverUrl = "https://bhuvan-vec1.nrsc.gov.in/bhuvan/wms",
            layerName = "KL_Cad",
            crs = "EPSG:4326",
            format = "image/png",
            opacity = 0.85f,
            isVisible = true
        ),
        WmsLayer(
            name = "NOAA Weather Radar",
            serverUrl = "https://nowcoast.noaa.gov/arcgis/services/nowcoast/radar_meteo_imagery_nexrad_time/MapServer/WMSServer",
            layerName = "1",
            opacity = 0.75f,
            isVisible = false
        ),
        WmsLayer(
            name = "USGS Topo WMS",
            serverUrl = "https://basemap.nationalmap.gov/arcgis/services/USGSTopo/MapServer/WMSServer",
            layerName = "0",
            opacity = 0.85f,
            isVisible = false
        ),
        WmsLayer(
            name = "NASA Earth MODIS Temperature",
            serverUrl = "https://neowms.sci.gsfc.nasa.gov/wms/wms",
            layerName = "MOD_LSTD_M_REFL",
            opacity = 0.6f,
            isVisible = false
        ),
        WmsLayer(
            name = "Bhuvan ISRO WMS",
            serverUrl = "https://bhuvan-vec1.nrsc.gov.in/bhuvan/wms",
            layerName = "india3",
            opacity = 0.8f,
            isVisible = false
        ),
        WmsLayer(
            name = "GEBCO Ocean Bathymetry",
            serverUrl = "https://www.gebco.net/data_and_products/gebco_web_services/web_map_service/mapserv",
            layerName = "GEBCO_LATEST",
            opacity = 0.7f,
            isVisible = false
        )
    )
}
