package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wms_layers")
data class WmsLayer(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val serverUrl: String,
    val layerName: String,
    val style: String = "",
    val format: String = "image/png",
    val transparent: Boolean = true,
    val opacity: Float = 0.8f,
    val isVisible: Boolean = true,
    val crs: String = "EPSG:3857",
    val timestamp: Long = System.currentTimeMillis()
)
