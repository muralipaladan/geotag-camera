package com.example.map

import org.osmdroid.tileprovider.tilesource.ITileSource
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.MapTileIndex

enum class BaseMapType(val displayName: String) {
    GOOGLE_SATELLITE("Google Satellite"),
    GOOGLE_HYBRID("Google Hybrid"),
    GOOGLE_NORMAL("Google Street"),
    GOOGLE_TERRAIN("Google Terrain"),
    OPEN_STREET_MAP("OpenStreetMap"),
    OPEN_TOPO_MAP("OpenTopoMap")
}

object BaseMapTileSources {

    val GOOGLE_NORMAL_SOURCE: ITileSource = object : OnlineTileSourceBase(
        "GoogleNormal",
        0,
        20,
        256,
        ".png",
        arrayOf("https://mt0.google.com/vt/lyrs=m&x=%d&y=%d&z=%d", "https://mt1.google.com/vt/lyrs=m&x=%d&y=%d&z=%d")
    ) {
        override fun getTileURLString(pMapTileIndex: Long): String {
            val x = MapTileIndex.getX(pMapTileIndex)
            val y = MapTileIndex.getY(pMapTileIndex)
            val z = MapTileIndex.getZoom(pMapTileIndex)
            return "https://mt1.google.com/vt/lyrs=m&x=$x&y=$y&z=$z"
        }
    }

    val GOOGLE_SATELLITE_SOURCE: ITileSource = object : OnlineTileSourceBase(
        "GoogleSatellite",
        0,
        20,
        256,
        ".jpg",
        arrayOf("https://mt0.google.com/vt/lyrs=s&x=%d&y=%d&z=%d", "https://mt1.google.com/vt/lyrs=s&x=%d&y=%d&z=%d")
    ) {
        override fun getTileURLString(pMapTileIndex: Long): String {
            val x = MapTileIndex.getX(pMapTileIndex)
            val y = MapTileIndex.getY(pMapTileIndex)
            val z = MapTileIndex.getZoom(pMapTileIndex)
            return "https://mt1.google.com/vt/lyrs=s&x=$x&y=$y&z=$z"
        }
    }

    val GOOGLE_HYBRID_SOURCE: ITileSource = object : OnlineTileSourceBase(
        "GoogleHybrid",
        0,
        20,
        256,
        ".png",
        arrayOf("https://mt0.google.com/vt/lyrs=y&x=%d&y=%d&z=%d", "https://mt1.google.com/vt/lyrs=y&x=%d&y=%d&z=%d")
    ) {
        override fun getTileURLString(pMapTileIndex: Long): String {
            val x = MapTileIndex.getX(pMapTileIndex)
            val y = MapTileIndex.getY(pMapTileIndex)
            val z = MapTileIndex.getZoom(pMapTileIndex)
            return "https://mt1.google.com/vt/lyrs=y&x=$x&y=$y&z=$z"
        }
    }

    val GOOGLE_TERRAIN_SOURCE: ITileSource = object : OnlineTileSourceBase(
        "GoogleTerrain",
        0,
        20,
        256,
        ".png",
        arrayOf("https://mt0.google.com/vt/lyrs=p&x=%d&y=%d&z=%d", "https://mt1.google.com/vt/lyrs=p&x=%d&y=%d&z=%d")
    ) {
        override fun getTileURLString(pMapTileIndex: Long): String {
            val x = MapTileIndex.getX(pMapTileIndex)
            val y = MapTileIndex.getY(pMapTileIndex)
            val z = MapTileIndex.getZoom(pMapTileIndex)
            return "https://mt1.google.com/vt/lyrs=p&x=$x&y=$y&z=$z"
        }
    }

    fun getTileSource(type: BaseMapType): ITileSource {
        return when (type) {
            BaseMapType.GOOGLE_SATELLITE -> GOOGLE_SATELLITE_SOURCE
            BaseMapType.GOOGLE_HYBRID -> GOOGLE_HYBRID_SOURCE
            BaseMapType.GOOGLE_NORMAL -> GOOGLE_NORMAL_SOURCE
            BaseMapType.GOOGLE_TERRAIN -> GOOGLE_TERRAIN_SOURCE
            BaseMapType.OPEN_STREET_MAP -> TileSourceFactory.MAPNIK
            BaseMapType.OPEN_TOPO_MAP -> TileSourceFactory.OpenTopo
        }
    }
}
