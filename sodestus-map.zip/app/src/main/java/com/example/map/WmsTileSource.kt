package com.example.map

import com.example.data.WmsLayer
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.util.MapTileIndex
import kotlin.math.PI

class WmsTileSource(
    val wmsLayer: WmsLayer
) : OnlineTileSourceBase(
    "WMS_${wmsLayer.id}_${wmsLayer.layerName.replace(":", "_")}_${wmsLayer.crs}",
    0,
    22,
    256,
    ".png",
    arrayOf(cleanUrl(wmsLayer.serverUrl))
) {
    private val originShift = 2.0 * PI * 6378137.0 / 2.0 // 20037508.342789244
    private val initialResolution = 2.0 * PI * 6378137.0 / 256.0

    override fun getTileURLString(pMapTileIndex: Long): String {
        val x = MapTileIndex.getX(pMapTileIndex)
        val y = MapTileIndex.getY(pMapTileIndex)
        val zoom = MapTileIndex.getZoom(pMapTileIndex)

        val isEpsg4326 = wmsLayer.crs.contains("4326") || wmsLayer.crs.contains("7326")
        val crsValue = if (isEpsg4326) "EPSG:4326" else "EPSG:3857"

        val bbox = tileToBBox(x, y, zoom, isEpsg4326)

        val baseUrl = cleanUrl(wmsLayer.serverUrl)
        val separator = if (baseUrl.contains("?")) "&" else "?"

        val version = "1.1.1"
        val crsParam = "SRS=$crsValue"
        val layerName = wmsLayer.layerName.trim()
        val style = wmsLayer.style.trim()
        val format = if (wmsLayer.format.isBlank()) "image/png" else wmsLayer.format.trim()

        return "$baseUrl${separator}SERVICE=WMS&VERSION=$version&REQUEST=GetMap&LAYERS=$layerName" +
                "&STYLES=$style&$crsParam&FORMAT=$format&TRANSPARENT=${wmsLayer.transparent.toString().uppercase()}" +
                "&WIDTH=256&HEIGHT=256&BBOX=$bbox"
    }

    private fun tileToBBox(x: Int, y: Int, zoom: Int, isEpsg4326: Boolean): String {
        if (isEpsg4326) {
            val n = 1 shl zoom
            val minLon = x.toDouble() / n * 360.0 - 180.0
            val maxLon = (x + 1).toDouble() / n * 360.0 - 180.0
            val maxLat = Math.toDegrees(Math.atan(Math.sinh(PI * (1.0 - 2.0 * y.toDouble() / n))))
            val minLat = Math.toDegrees(Math.atan(Math.sinh(PI * (1.0 - 2.0 * (y + 1).toDouble() / n))))
            return "$minLon,$minLat,$maxLon,$maxLat"
        } else {
            val res = initialResolution / (1 shl zoom)
            val minX = x * res * 256.0 - originShift
            val maxX = (x + 1) * res * 256.0 - originShift
            val maxY = originShift - y * res * 256.0
            val minY = originShift - (y + 1) * res * 256.0
            return "$minX,$minY,$maxX,$maxY"
        }
    }

    companion object {
        fun cleanUrl(url: String): String {
            var u = url.trim()
            while (u.endsWith("/") || u.endsWith("?")) {
                u = u.dropLast(1).trim()
            }
            return u
        }
    }
}

