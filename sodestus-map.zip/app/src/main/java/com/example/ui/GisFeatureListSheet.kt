package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Polyline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.FeatureType
import com.example.data.GisFeature
import com.example.util.GeoUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GisFeatureListSheet(
    gisFeatures: List<GisFeature>,
    onSelectFeature: (GisFeature) -> Unit,
    onDeleteFeature: (GisFeature) -> Unit,
    onExportGeoJson: () -> String,
    onImportGeoJson: (String) -> Boolean,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var showGeoJsonExportDialog by remember { mutableStateOf(false) }
    var showGeoJsonImportDialog by remember { mutableStateOf(false) }
    var exportedText by remember { mutableStateOf("") }
    var importInputText by remember { mutableStateOf("") }

    val filteredFeatures = remember(gisFeatures, searchQuery) {
        if (searchQuery.isBlank()) {
            gisFeatures
        } else {
            gisFeatures.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                        it.category.contains(searchQuery, ignoreCase = true) ||
                        it.description.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Saved GIS Features (${gisFeatures.size})",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                Row {
                    OutlinedButton(
                        onClick = {
                            exportedText = onExportGeoJson()
                            showGeoJsonExportDialog = true
                        }
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export")
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { showGeoJsonImportDialog = true }
                    ) {
                        Icon(Icons.Default.Upload, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Import")
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search waypoints, lines, boundaries...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredFeatures.isEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp)
                    ) {
                        Text(
                            text = "No Features Found",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Use the map tools to drop waypoints or draw polylines & polygons.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp)
                ) {
                    items(filteredFeatures, key = { it.id }) { feature ->
                        FeatureCard(
                            feature = feature,
                            onClick = {
                                onSelectFeature(feature)
                                onDismiss()
                            },
                            onDelete = { onDeleteFeature(feature) }
                        )
                    }
                }
            }
        }
    }

    // Export GeoJSON Dialog
    if (showGeoJsonExportDialog) {
        AlertDialog(
            onDismissRequest = { showGeoJsonExportDialog = false },
            title = { Text("GeoJSON Data Export") },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Standard GeoJSON format containing all waypoints, paths, and polygons:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = exportedText,
                        onValueChange = {},
                        readOnly = true,
                        maxLines = 8,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("GeoJSON", exportedText)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "GeoJSON copied to clipboard!", Toast.LENGTH_SHORT).show()
                        showGeoJsonExportDialog = false
                    }
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy GeoJSON")
                }
            },
            dismissButton = {
                TextButton(onClick = { showGeoJsonExportDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // Import GeoJSON Dialog
    if (showGeoJsonImportDialog) {
        AlertDialog(
            onDismissRequest = { showGeoJsonImportDialog = false },
            title = { Text("Import GeoJSON") },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Paste GeoJSON string below to import spatial features:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = importInputText,
                        onValueChange = { importInputText = it },
                        placeholder = { Text("{\"type\": \"FeatureCollection\", ...}") },
                        maxLines = 8,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (importInputText.isNotBlank()) {
                            val success = onImportGeoJson(importInputText)
                            if (success) {
                                Toast.makeText(context, "Features imported successfully!", Toast.LENGTH_SHORT).show()
                                showGeoJsonImportDialog = false
                            } else {
                                Toast.makeText(context, "Invalid GeoJSON format!", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                ) {
                    Text("Import Features")
                }
            },
            dismissButton = {
                TextButton(onClick = { showGeoJsonImportDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun FeatureCard(
    feature: GisFeature,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val icon = when (feature.featureType) {
        FeatureType.WAYPOINT -> Icons.Default.LocationOn
        FeatureType.LINE -> Icons.Default.Polyline
        FeatureType.POLYGON -> Icons.Default.Polyline
    }

    val detailText = when (feature.featureType) {
        FeatureType.WAYPOINT -> "Waypoint (${feature.category})"
        FeatureType.LINE -> "Distance: ${GeoUtils.formatDistance(feature.lengthMeters)}"
        FeatureType.POLYGON -> "Area: ${GeoUtils.formatArea(feature.areaSqMeters)}"
    }

    Card(
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(14.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(end = 12.dp)
            )

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = feature.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = detailText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                if (feature.description.isNotBlank()) {
                    Text(
                        text = feature.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
