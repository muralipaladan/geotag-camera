package com.example.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.WmsLayer
import com.example.util.GeoCoord
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

@Composable
fun GisMapAppScreen(
    viewModel: GisViewModel = viewModel()
) {
    val context = LocalContext.current

    val selectedBaseMap by viewModel.selectedBaseMap.collectAsStateWithLifecycle()
    val wmsLayers by viewModel.wmsLayers.collectAsStateWithLifecycle()
    val gisFeatures by viewModel.gisFeatures.collectAsStateWithLifecycle()
    val toolMode by viewModel.toolMode.collectAsStateWithLifecycle()
    val draftPoints by viewModel.draftPoints.collectAsStateWithLifecycle()
    val userLocation by viewModel.userLocation.collectAsStateWithLifecycle()
    val selectedFeature by viewModel.selectedFeature.collectAsStateWithLifecycle()
    val gpsStatus by viewModel.gpsStatus.collectAsStateWithLifecycle()

    val showWmsDialog by viewModel.showWmsDialog.collectAsStateWithLifecycle()
    val showLayersSheet by viewModel.showLayersSheet.collectAsStateWithLifecycle()
    val showFeatureListSheet by viewModel.showFeatureListSheet.collectAsStateWithLifecycle()
    val editingWmsLayer by viewModel.editingWmsLayer.collectAsStateWithLifecycle()

    var showBaseMapSheet by remember { mutableStateOf(false) }
    var showSaveFeatureDialog by remember { mutableStateOf(false) }
    var showSearchDialog by remember { mutableStateOf(false) }
    var searchTargetLocation by remember { mutableStateOf<com.example.util.GeoCoord?>(null) }
    var searchTargetTrigger by remember { mutableStateOf(0L) }
    var centerOnUserTrigger by remember { mutableStateOf(0L) }
    var zoomInTrigger by remember { mutableStateOf(0L) }
    var zoomOutTrigger by remember { mutableStateOf(0L) }

    var isLocationPermissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }

    // Request Location Permission
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
        if (fineGranted || coarseGranted) {
            isLocationPermissionGranted = true
            Toast.makeText(context, "GPS Location granted", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) {
        if (!isLocationPermissionGranted) {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    // Connect to Google Fused Location Engine for smooth GPS updates
    DisposableEffect(isLocationPermissionGranted) {
        if (!isLocationPermissionGranted) {
            return@DisposableEffect onDispose {}
        }

        val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)

        val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 2000L)
            .setMinUpdateIntervalMillis(1000L)
            .setMinUpdateDistanceMeters(1.0f)
            .build()

        val locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { loc ->
                    viewModel.updateGpsLocation(loc)
                }
            }
        }

        try {
            // Immediate last location fix for instant blue dot
            fusedLocationClient.lastLocation.addOnSuccessListener { loc ->
                if (loc != null) {
                    viewModel.updateGpsLocation(loc)
                }
            }

            // High accuracy fused location updates
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper())
        } catch (e: SecurityException) {
            e.printStackTrace()
        }

        onDispose {
            try {
                fusedLocationClient.removeLocationUpdates(locationCallback)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Full screen Osmdroid GIS Map
            MapViewContainer(
                selectedBaseMap = selectedBaseMap,
                wmsLayers = wmsLayers,
                gisFeatures = gisFeatures,
                toolMode = toolMode,
                draftPoints = draftPoints,
                userLocation = userLocation,
                selectedFeature = selectedFeature,
                centerOnUserTrigger = centerOnUserTrigger,
                searchTargetLocation = searchTargetLocation,
                searchTargetTrigger = searchTargetTrigger,
                zoomInTrigger = zoomInTrigger,
                zoomOutTrigger = zoomOutTrigger,
                gpsStatus = gpsStatus,
                onMapClick = { point ->
                    if (toolMode != MapToolMode.NONE) {
                        viewModel.addDraftPoint(point)
                    } else {
                        viewModel.selectFeature(null)
                    }
                },
                onFeatureSelect = { feature ->
                    if (toolMode == MapToolMode.NONE) {
                        viewModel.selectFeature(feature)
                    }
                },
                onUserLocationUpdate = { coord ->
                    viewModel.updateUserLocation(coord)
                }
            )

            // Top Bar
            TopMapBar(
                selectedBaseMap = selectedBaseMap,
                activeWmsCount = wmsLayers.count { it.isVisible },
                totalFeatureCount = gisFeatures.size,
                gpsStatus = gpsStatus,
                onOpenBaseMapSelector = { showBaseMapSheet = true },
                onOpenWmsManager = { viewModel.toggleLayersSheet(true) },
                onOpenFeatureList = { viewModel.toggleFeatureListSheet(true) },
                modifier = Modifier.align(Alignment.TopCenter)
            )

            // Selected Feature Inspector Overlay
            selectedFeature?.let { feature ->
                if (toolMode == MapToolMode.NONE) {
                    FeatureInspectorCard(
                        feature = feature,
                        onClose = { viewModel.selectFeature(null) },
                        onDelete = { viewModel.deleteFeature(feature) },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 90.dp)
                    )
                }
            }

            // Drawing / Surveying Measurement HUD
            if (toolMode != MapToolMode.NONE) {
                DrawingSurveyHud(
                    toolMode = toolMode,
                    draftPoints = draftPoints,
                    onUndo = { viewModel.undoDraftPoint() },
                    onClear = { viewModel.clearDraftPoints() },
                    onSave = { showSaveFeatureDialog = true },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 90.dp)
                )
            }

            // Bottom Navigation & Mode Switcher
            BottomToolBar(
                currentToolMode = toolMode,
                onSelectToolMode = { mode -> viewModel.setToolMode(mode) },
                onLocateMe = {
                    centerOnUserTrigger = System.currentTimeMillis()
                    val loc = userLocation
                    if (loc != null) {
                        Toast.makeText(context, "Centering on GPS Location: ${String.format("%.4f", loc.lat)}, ${String.format("%.4f", loc.lon)}", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Fetching GPS location blue dot...", Toast.LENGTH_SHORT).show()
                    }
                },
                onOpenSearch = { showSearchDialog = true },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }

    // Sheets & Dialogs
    if (showSearchDialog) {
        LocationSearchDialog(
            onSelectLocation = { coord, name ->
                searchTargetLocation = coord
                searchTargetTrigger = System.currentTimeMillis()
                Toast.makeText(context, "Navigating to: $name", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showSearchDialog = false }
        )
    }
    if (showBaseMapSheet) {
        BaseMapSelectorSheet(
            selectedBaseMap = selectedBaseMap,
            onSelectBaseMap = { type -> viewModel.setBaseMap(type) },
            onDismiss = { showBaseMapSheet = false }
        )
    }

    if (showLayersSheet) {
        WmsManagerSheet(
            wmsLayers = wmsLayers,
            onToggleVisibility = { layer -> viewModel.toggleWmsVisibility(layer) },
            onUpdateOpacity = { layer, opacity -> viewModel.updateWmsOpacity(layer, opacity) },
            onEditLayer = { layer -> viewModel.toggleWmsDialog(true, layer) },
            onDeleteLayer = { layer -> viewModel.deleteWmsLayer(layer) },
            onAddNewWms = { viewModel.toggleWmsDialog(true, null) },
            onDismiss = { viewModel.toggleLayersSheet(false) }
        )
    }

    if (showWmsDialog) {
        WmsEditDialog(
            editingLayer = editingWmsLayer,
            onSave = { name, url, layerName, style, opacity ->
                viewModel.saveWmsLayer(name, url, layerName, style, opacity)
            },
            onDismiss = { viewModel.toggleWmsDialog(false) }
        )
    }

    if (showFeatureListSheet) {
        GisFeatureListSheet(
            gisFeatures = gisFeatures,
            onSelectFeature = { feature ->
                viewModel.selectFeature(feature)
            },
            onDeleteFeature = { feature ->
                viewModel.deleteFeature(feature)
            },
            onExportGeoJson = {
                viewModel.exportFeaturesToGeoJson()
            },
            onImportGeoJson = { jsonStr ->
                viewModel.importGeoJson(jsonStr)
            },
            onDismiss = { viewModel.toggleFeatureListSheet(false) }
        )
    }

    if (showSaveFeatureDialog) {
        SaveFeatureDialog(
            toolMode = toolMode,
            draftPoints = draftPoints,
            onSave = { title, desc, cat, color ->
                viewModel.saveCurrentDraftFeature(title, desc, cat, color)
                showSaveFeatureDialog = false
            },
            onDismiss = { showSaveFeatureDialog = false }
        )
    }
}
