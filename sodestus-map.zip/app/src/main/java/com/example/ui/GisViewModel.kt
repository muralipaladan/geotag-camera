package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.FeatureType
import com.example.data.GisDatabase
import com.example.data.GisFeature
import com.example.data.GisRepository
import com.example.data.SampleWmsServers
import com.example.data.WmsLayer
import com.example.map.BaseMapType
import com.example.util.GeoCoord
import com.example.util.GeoUtils
import com.example.util.GpsStatusInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

enum class MapToolMode {
    NONE,
    ADD_WAYPOINT,
    DRAW_LINE,
    DRAW_POLYGON
}

class GisViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GisRepository
    val wmsLayers: StateFlow<List<WmsLayer>>
    val gisFeatures: StateFlow<List<GisFeature>>

    private val _selectedBaseMap = MutableStateFlow(BaseMapType.GOOGLE_NORMAL)
    val selectedBaseMap: StateFlow<BaseMapType> = _selectedBaseMap.asStateFlow()

    private val _toolMode = MutableStateFlow(MapToolMode.NONE)
    val toolMode: StateFlow<MapToolMode> = _toolMode.asStateFlow()

    private val _draftPoints = MutableStateFlow<List<GeoCoord>>(emptyList())
    val draftPoints: StateFlow<List<GeoCoord>> = _draftPoints.asStateFlow()

    private val _userLocation = MutableStateFlow<GeoCoord?>(null)
    val userLocation: StateFlow<GeoCoord?> = _userLocation.asStateFlow()

    private val _gpsStatus = MutableStateFlow(GpsStatusInfo())
    val gpsStatus: StateFlow<GpsStatusInfo> = _gpsStatus.asStateFlow()

    private val _selectedFeature = MutableStateFlow<GisFeature?>(null)
    val selectedFeature: StateFlow<GisFeature?> = _selectedFeature.asStateFlow()

    private val _showWmsDialog = MutableStateFlow(false)
    val showWmsDialog: StateFlow<Boolean> = _showWmsDialog.asStateFlow()

    private val _showLayersSheet = MutableStateFlow(false)
    val showLayersSheet: StateFlow<Boolean> = _showLayersSheet.asStateFlow()

    private val _showFeatureListSheet = MutableStateFlow(false)
    val showFeatureListSheet: StateFlow<Boolean> = _showFeatureListSheet.asStateFlow()

    private val _editingWmsLayer = MutableStateFlow<WmsLayer?>(null)
    val editingWmsLayer: StateFlow<WmsLayer?> = _editingWmsLayer.asStateFlow()

    init {
        val dao = GisDatabase.getDatabase(application).gisDao()
        repository = GisRepository(dao)

        wmsLayers = repository.allWmsLayers.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        gisFeatures = repository.allGisFeatures.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        // Seed sample WMS servers if DB is empty or missing Cadastral layer
        viewModelScope.launch {
            val existing = repository.allWmsLayers.first()
            if (existing.isEmpty()) {
                SampleWmsServers.presets.forEach { repository.insertWmsLayer(it) }
            } else {
                val cadastralLayer = existing.find { it.layerName.contains("cadastral", ignoreCase = true) || it.layerName.contains("KL_Cad", ignoreCase = true) || it.name == "9400849115" || it.name == "Bhuvan Cadastral India" }
                if (cadastralLayer == null) {
                    repository.insertWmsLayer(SampleWmsServers.presets.first())
                } else {
                    val updated = cadastralLayer.copy(
                        name = "9400849115",
                        serverUrl = "https://bhuvan-vec1.nrsc.gov.in/bhuvan/wms",
                        layerName = "KL_Cad",
                        crs = "EPSG:4326",
                        format = "image/png"
                    )
                    if (cadastralLayer.name != updated.name ||
                        cadastralLayer.serverUrl != updated.serverUrl ||
                        cadastralLayer.layerName != updated.layerName ||
                        cadastralLayer.crs != updated.crs ||
                        cadastralLayer.format != updated.format) {
                        repository.updateWmsLayer(updated)
                    }
                }
            }
        }
    }

    fun setBaseMap(type: BaseMapType) {
        _selectedBaseMap.value = type
    }

    fun setToolMode(mode: MapToolMode) {
        _toolMode.value = mode
        if (mode == MapToolMode.NONE) {
            _draftPoints.value = emptyList()
        }
    }

    fun addDraftPoint(point: GeoCoord) {
        val currentMode = _toolMode.value
        if (currentMode == MapToolMode.ADD_WAYPOINT) {
            _draftPoints.value = listOf(point)
        } else if (currentMode == MapToolMode.DRAW_LINE || currentMode == MapToolMode.DRAW_POLYGON) {
            _draftPoints.value = _draftPoints.value + point
        }
    }

    fun undoDraftPoint() {
        val current = _draftPoints.value
        if (current.isNotEmpty()) {
            _draftPoints.value = current.dropLast(1)
        }
    }

    fun clearDraftPoints() {
        _draftPoints.value = emptyList()
    }

    fun updateUserLocation(coord: GeoCoord) {
        _userLocation.value = coord
    }

    fun updateGpsLocation(location: android.location.Location) {
        val coord = GeoCoord(location.latitude, location.longitude, location.altitude)
        _userLocation.value = coord
        _gpsStatus.value = GpsStatusInfo(
            isGpsActive = true,
            accuracyMeters = location.accuracy,
            speedKmh = location.speed * 3.6f,
            provider = location.provider?.replaceFirstChar { it.uppercase() } ?: "Google Fused Location",
            lat = location.latitude,
            lon = location.longitude,
            altitude = location.altitude,
            lastFixTimestamp = System.currentTimeMillis()
        )
    }

    fun selectFeature(feature: GisFeature?) {
        _selectedFeature.value = feature
    }

    fun toggleWmsDialog(show: Boolean, layerToEdit: WmsLayer? = null) {
        _editingWmsLayer.value = layerToEdit
        _showWmsDialog.value = show
    }

    fun toggleLayersSheet(show: Boolean) {
        _showLayersSheet.value = show
    }

    fun toggleFeatureListSheet(show: Boolean) {
        _showFeatureListSheet.value = show
    }

    fun saveWmsLayer(name: String, url: String, layerName: String, style: String, opacity: Float) {
        viewModelScope.launch {
            val layerToEdit = _editingWmsLayer.value
            if (layerToEdit != null) {
                repository.updateWmsLayer(
                    layerToEdit.copy(
                        name = name.ifBlank { "WMS Layer" },
                        serverUrl = url.trim(),
                        layerName = layerName.trim(),
                        style = style.trim(),
                        opacity = opacity
                    )
                )
            } else {
                repository.insertWmsLayer(
                    WmsLayer(
                        name = name.ifBlank { "WMS Layer" },
                        serverUrl = url.trim(),
                        layerName = layerName.trim(),
                        style = style.trim(),
                        opacity = opacity,
                        isVisible = true
                    )
                )
            }
            toggleWmsDialog(false)
        }
    }

    fun toggleWmsVisibility(layer: WmsLayer) {
        viewModelScope.launch {
            repository.updateWmsLayer(layer.copy(isVisible = !layer.isVisible))
        }
    }

    fun updateWmsOpacity(layer: WmsLayer, opacity: Float) {
        viewModelScope.launch {
            repository.updateWmsLayer(layer.copy(opacity = opacity))
        }
    }

    fun deleteWmsLayer(layer: WmsLayer) {
        if (layer.name == "9400849115" || layer.layerName.contains("cadastral", ignoreCase = true) || layer.layerName.contains("KL_Cad", ignoreCase = true)) {
            // Protected permanent layer - cannot be deleted
            return
        }
        viewModelScope.launch {
            repository.deleteWmsLayer(layer)
        }
    }

    fun saveCurrentDraftFeature(title: String, description: String, category: String, colorHex: String) {
        val points = _draftPoints.value
        if (points.isEmpty()) return

        val mode = _toolMode.value
        val type = when (mode) {
            MapToolMode.ADD_WAYPOINT -> FeatureType.WAYPOINT
            MapToolMode.DRAW_LINE -> FeatureType.LINE
            MapToolMode.DRAW_POLYGON -> FeatureType.POLYGON
            else -> return
        }

        val lengthMeters = if (type == FeatureType.LINE || type == FeatureType.POLYGON) {
            GeoUtils.calculatePathLengthMeters(points)
        } else 0.0

        val areaSqMeters = if (type == FeatureType.POLYGON) {
            GeoUtils.calculatePolygonAreaSqMeters(points)
        } else 0.0

        viewModelScope.launch {
            repository.insertGisFeature(
                GisFeature(
                    title = title.ifBlank { "${type.name.lowercase().replaceFirstChar { it.uppercase() }} #${System.currentTimeMillis() % 1000}" },
                    description = description,
                    featureType = type,
                    pointsJson = GeoUtils.pointsToJson(points),
                    colorHex = colorHex,
                    lengthMeters = lengthMeters,
                    areaSqMeters = areaSqMeters,
                    category = category.ifBlank { "General" }
                )
            )
            setToolMode(MapToolMode.NONE)
        }
    }

    fun deleteFeature(feature: GisFeature) {
        viewModelScope.launch {
            repository.deleteGisFeature(feature)
            if (_selectedFeature.value?.id == feature.id) {
                _selectedFeature.value = null
            }
        }
    }

    fun exportFeaturesToGeoJson(): String {
        val features = gisFeatures.value
        val featureArray = JSONArray()

        for (f in features) {
            val points = GeoUtils.pointsFromJson(f.pointsJson)
            val geometryObj = JSONObject()

            when (f.featureType) {
                FeatureType.WAYPOINT -> {
                    if (points.isNotEmpty()) {
                        geometryObj.put("type", "Point")
                        geometryObj.put("coordinates", JSONArray().apply {
                            put(points[0].lon)
                            put(points[0].lat)
                        })
                    }
                }
                FeatureType.LINE -> {
                    geometryObj.put("type", "LineString")
                    val coordsArr = JSONArray()
                    points.forEach {
                        coordsArr.put(JSONArray().apply {
                            put(it.lon)
                            put(it.lat)
                        })
                    }
                    geometryObj.put("coordinates", coordsArr)
                }
                FeatureType.POLYGON -> {
                    geometryObj.put("type", "Polygon")
                    val ringArr = JSONArray()
                    val closedPoints = if (points.isNotEmpty() && points.first() != points.last()) {
                        points + points.first()
                    } else points
                    closedPoints.forEach {
                        ringArr.put(JSONArray().apply {
                            put(it.lon)
                            put(it.lat)
                        })
                    }
                    geometryObj.put("coordinates", JSONArray().put(ringArr))
                }
            }

            val propsObj = JSONObject().apply {
                put("id", f.id)
                put("title", f.title)
                put("description", f.description)
                put("category", f.category)
                put("color", f.colorHex)
                put("lengthMeters", f.lengthMeters)
                put("areaSqMeters", f.areaSqMeters)
            }

            val featureObj = JSONObject().apply {
                put("type", "Feature")
                put("geometry", geometryObj)
                put("properties", propsObj)
            }

            featureArray.put(featureObj)
        }

        val rootObj = JSONObject().apply {
            put("type", "FeatureCollection")
            put("features", featureArray)
        }

        return rootObj.toString(2)
    }

    fun importGeoJson(geoJsonStr: String): Boolean {
        return try {
            val root = JSONObject(geoJsonStr)
            val features = root.optJSONArray("features") ?: return false

            viewModelScope.launch {
                for (i in 0 until features.length()) {
                    val feature = features.getJSONObject(i)
                    val geom = feature.getJSONObject("geometry")
                    val props = feature.optJSONObject("properties") ?: JSONObject()

                    val geomType = geom.getString("type")
                    val coords = geom.getJSONArray("coordinates")

                    val title = props.optString("title", "Imported $geomType")
                    val desc = props.optString("description", "")
                    val color = props.optString("color", "#FF2196F3")

                    val pointsList = mutableListOf<GeoCoord>()

                    when (geomType) {
                        "Point" -> {
                            val lon = coords.getDouble(0)
                            val lat = coords.getDouble(1)
                            pointsList.add(GeoCoord(lat, lon))
                            repository.insertGisFeature(
                                GisFeature(
                                    title = title,
                                    description = desc,
                                    featureType = FeatureType.WAYPOINT,
                                    pointsJson = GeoUtils.pointsToJson(pointsList),
                                    colorHex = color
                                )
                            )
                        }
                        "LineString" -> {
                            for (j in 0 until coords.length()) {
                                val pt = coords.getJSONArray(j)
                                pointsList.add(GeoCoord(pt.getDouble(1), pt.getDouble(0)))
                            }
                            repository.insertGisFeature(
                                GisFeature(
                                    title = title,
                                    description = desc,
                                    featureType = FeatureType.LINE,
                                    pointsJson = GeoUtils.pointsToJson(pointsList),
                                    colorHex = color,
                                    lengthMeters = GeoUtils.calculatePathLengthMeters(pointsList)
                                )
                            )
                        }
                        "Polygon" -> {
                            if (coords.length() > 0) {
                                val ring = coords.getJSONArray(0)
                                for (j in 0 until ring.length()) {
                                    val pt = ring.getJSONArray(j)
                                    pointsList.add(GeoCoord(pt.getDouble(1), pt.getDouble(0)))
                                }
                                repository.insertGisFeature(
                                    GisFeature(
                                        title = title,
                                        description = desc,
                                        featureType = FeatureType.POLYGON,
                                        pointsJson = GeoUtils.pointsToJson(pointsList),
                                        colorHex = color,
                                        lengthMeters = GeoUtils.calculatePathLengthMeters(pointsList),
                                        areaSqMeters = GeoUtils.calculatePolygonAreaSqMeters(pointsList)
                                    )
                                )
                            }
                        }
                    }
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
