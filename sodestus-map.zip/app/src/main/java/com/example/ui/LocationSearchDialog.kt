package com.example.ui

import android.content.Context
import android.location.Geocoder
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.GeoCoord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

data class SearchResultItem(
    val name: String,
    val address: String,
    val lat: Double,
    val lon: Double
)

private val PRESET_KERALA_LOCATIONS = listOf(
    SearchResultItem("Palakkad", "Palakkad, Kerala, India", 10.7867, 76.6548),
    SearchResultItem("Kochi (Ernakulam)", "Kochi, Kerala, India", 9.9312, 76.2673),
    SearchResultItem("Kozhikode (Calicut)", "Kozhikode, Kerala, India", 11.2588, 75.7804),
    SearchResultItem("Thiruvananthapuram", "Trivandrum, Kerala, India", 8.5241, 76.9366),
    SearchResultItem("Thrissur", "Thrissur, Kerala, India", 10.5276, 76.2144),
    SearchResultItem("Malappuram", "Malappuram, Kerala, India", 11.0720, 76.0740),
    SearchResultItem("Kannur", "Kannur, Kerala, India", 11.8745, 75.3704),
    SearchResultItem("Wayanad (Kalpetta)", "Wayanad, Kerala, India", 11.6103, 76.0827),
    SearchResultItem("Kottayam", "Kottayam, Kerala, India", 9.5916, 76.5222),
    SearchResultItem("Alappuzha (Alleppey)", "Alappuzha, Kerala, India", 9.4981, 76.3388),
    SearchResultItem("Idukki (Painavu)", "Idukki, Kerala, India", 9.8497, 76.9806),
    SearchResultItem("Kollam (Quilon)", "Kollam, Kerala, India", 8.8932, 76.6141),
    SearchResultItem("Kasaragod", "Kasaragod, Kerala, India", 12.4996, 74.9869),
    SearchResultItem("Pathanamthitta", "Pathanamthitta, Kerala, India", 9.2648, 76.7870)
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun LocationSearchDialog(
    onSelectLocation: (GeoCoord, String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<SearchResultItem>>(PRESET_KERALA_LOCATIONS) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun performSearch(query: String) {
        if (query.isBlank()) {
            searchResults = PRESET_KERALA_LOCATIONS
            errorMessage = null
            return
        }

        scope.launch {
            isLoading = true
            errorMessage = null

            // 1. Check if user entered direct lat, lon coordinates (e.g. "10.8505, 76.2711" or "10.8505 76.2711")
            val coordResult = parseCoordinates(query)
            if (coordResult != null) {
                searchResults = listOf(coordResult)
                isLoading = false
                return@launch
            }

            // 2. Perform online Geocoding via Nominatim OpenStreetMap API with Geocoder fallback
            val results = withContext(Dispatchers.IO) {
                fetchNominatimOrGeocoder(context, query)
            }

            if (results.isNotEmpty()) {
                searchResults = results
                errorMessage = null
            } else {
                searchResults = emptyList()
                errorMessage = "No matching locations found for '$query'. Try typing coordinates like 10.786, 76.654"
            }
            isLoading = false
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = "Search Location / GPS Coordinates",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Search place name, landmark, or enter Lat, Long (e.g. 10.786, 76.654)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = {
                    searchQuery = it
                    performSearch(it)
                },
                placeholder = { Text("Search location or enter coordinates...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = {
                            searchQuery = ""
                            performSearch("")
                        }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Location Chips (Kerala Districts)
            Text(
                text = "Quick Districts:",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(4.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                PRESET_KERALA_LOCATIONS.take(7).forEach { item ->
                    FilterChip(
                        selected = false,
                        onClick = {
                            searchQuery = item.name
                            performSearch(item.name)
                        },
                        label = { Text(item.name, fontSize = 12.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (isLoading) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Searching location maps...", style = MaterialTheme.typography.bodyMedium)
                }
            } else if (errorMessage != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = errorMessage ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    items(searchResults) { item ->
                        SearchResultCard(
                            item = item,
                            onClick = {
                                onSelectLocation(GeoCoord(item.lat, item.lon), item.name)
                                onDismiss()
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun SearchResultCard(
    item: SearchResultItem,
    onClick: () -> Unit
) {
    Card(
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(12.dp)
        ) {
            Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = item.address,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "GPS: ${String.format("%.5f", item.lat)}, ${String.format("%.5f", item.lon)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

private fun parseCoordinates(query: String): SearchResultItem? {
    try {
        val parts = query.split(Regex("[,\\s]+")).filter { it.isNotBlank() }
        if (parts.size >= 2) {
            val lat = parts[0].toDoubleOrNull()
            val lon = parts[1].toDoubleOrNull()
            if (lat != null && lon != null && lat in -90.0..90.0 && lon in -180.0..180.0) {
                return SearchResultItem(
                    name = "GPS Point (${String.format("%.4f", lat)}, ${String.format("%.4f", lon)})",
                    address = "Entered Latitude & Longitude Coordinates",
                    lat = lat,
                    lon = lon
                )
            }
        }
    } catch (e: Exception) {
        // ignore
    }
    return null
}

private suspend fun fetchNominatimOrGeocoder(context: Context, query: String): List<SearchResultItem> {
    val results = mutableListOf<SearchResultItem>()

    // Try Nominatim API
    try {
        val encodedQuery = URLEncoder.encode(query, "UTF-8")
        val url = URL("https://nominatim.openstreetmap.org/search?format=json&q=$encodedQuery&limit=10")
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", "GisMapApp/1.0 (Android GIS)")
        connection.connectTimeout = 3000
        connection.readTimeout = 3000

        if (connection.responseCode == 200) {
            val jsonText = connection.inputStream.bufferedReader().use { it.readText() }
            val jsonArray = JSONArray(jsonText)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val displayName = obj.optString("display_name", query)
                val lat = obj.optString("lat").toDoubleOrNull()
                val lon = obj.optString("lon").toDoubleOrNull()
                if (lat != null && lon != null) {
                    val namePart = displayName.split(",").firstOrNull()?.trim() ?: query
                    results.add(
                        SearchResultItem(
                            name = namePart,
                            address = displayName,
                            lat = lat,
                            lon = lon
                        )
                    )
                }
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }

    // Fallback to Android Geocoder if Nominatim returned empty
    if (results.isEmpty() && Geocoder.isPresent()) {
        try {
            val geocoder = Geocoder(context, Locale.getDefault())
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocationName(query, 5)
            addresses?.forEach { addr ->
                val title = addr.featureName ?: addr.locality ?: query
                val fullAddr = (0..addr.maxAddressLineIndex).joinToString(", ") { addr.getAddressLine(it) }
                results.add(
                    SearchResultItem(
                        name = title,
                        address = if (fullAddr.isNotBlank()) fullAddr else "$title, ${addr.countryName ?: ""}",
                        lat = addr.latitude,
                        lon = addr.longitude
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    return results
}
