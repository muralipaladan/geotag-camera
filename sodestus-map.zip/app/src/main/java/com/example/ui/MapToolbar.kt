package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLocation
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.GpsNotFixed
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Polyline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Square
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.map.BaseMapType
import com.example.util.GeoCoord
import com.example.util.GeoUtils
import com.example.util.GpsStatusInfo

@Composable
fun TopMapBar(
    selectedBaseMap: BaseMapType,
    activeWmsCount: Int,
    totalFeatureCount: Int,
    gpsStatus: GpsStatusInfo = GpsStatusInfo(),
    onOpenBaseMapSelector: () -> Unit,
    onOpenWmsManager: () -> Unit,
    onOpenFeatureList: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showGpsDetailsDialog by remember { mutableStateOf(false) }

    if (showGpsDetailsDialog) {
        GpsStatusDialog(
            gpsStatus = gpsStatus,
            onDismiss = { showGpsDetailsDialog = false }
        )
    }

    Surface(
        tonalElevation = 6.dp,
        shadowElevation = 8.dp,
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Sodestus Map",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary
                )

                if (gpsStatus.isGpsActive) {
                    Icon(
                        imageVector = Icons.Default.GpsFixed,
                        contentDescription = "GPS Active",
                        tint = Color(0xFF2E7D32),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Base Map Button
                Button(
                    onClick = onOpenBaseMapSelector,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                ) {
                    Icon(imageVector = Icons.Default.Map, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(selectedBaseMap.displayName, style = MaterialTheme.typography.labelMedium)
                }

                // WMS Layers Button
                IconButton(onClick = onOpenWmsManager) {
                    BadgedBox(
                        badge = {
                            if (activeWmsCount > 0) {
                                Badge { Text(activeWmsCount.toString()) }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = "WMS Services",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                // Saved GIS Features List Button
                IconButton(onClick = onOpenFeatureList) {
                    BadgedBox(
                        badge = {
                            if (totalFeatureCount > 0) {
                                Badge { Text(totalFeatureCount.toString()) }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.List,
                            contentDescription = "Saved Features",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BottomToolBar(
    currentToolMode: MapToolMode,
    onSelectToolMode: (MapToolMode) -> Unit,
    onLocateMe: () -> Unit,
    onOpenSearch: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        tonalElevation = 8.dp,
        shadowElevation = 10.dp,
        shape = RoundedCornerShape(32.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
        modifier = modifier.padding(bottom = 24.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Location Search Tool Button
            ToolIconButton(
                icon = Icons.Default.Search,
                label = "Search",
                isSelected = false,
                onClick = onOpenSearch
            )

            // Show exit/pan button only when in drawing mode
            if (currentToolMode != MapToolMode.NONE) {
                ToolIconButton(
                    icon = Icons.Default.Clear,
                    label = "Exit Tool",
                    isSelected = false,
                    onClick = { onSelectToolMode(MapToolMode.NONE) }
                )
            }

            ToolIconButton(
                icon = Icons.Default.AddLocation,
                label = "Waypoint",
                isSelected = currentToolMode == MapToolMode.ADD_WAYPOINT,
                onClick = { onSelectToolMode(MapToolMode.ADD_WAYPOINT) }
            )

            ToolIconButton(
                icon = Icons.Default.Polyline,
                label = "Measure Line",
                isSelected = currentToolMode == MapToolMode.DRAW_LINE,
                onClick = { onSelectToolMode(MapToolMode.DRAW_LINE) }
            )

            ToolIconButton(
                icon = Icons.Default.Square,
                label = "Measure Area",
                isSelected = currentToolMode == MapToolMode.DRAW_POLYGON,
                onClick = { onSelectToolMode(MapToolMode.DRAW_POLYGON) }
            )

            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
            ) {
                IconButton(
                    onClick = onLocateMe,
                    modifier = Modifier.align(Alignment.Center)
                ) {
                    Icon(
                        imageVector = Icons.Default.MyLocation,
                        contentDescription = "GPS Location",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
fun ToolIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val containerColor = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent
    val contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant

    Box(
        modifier = Modifier.background(containerColor, CircleShape)
    ) {
        IconButton(onClick = onClick) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = contentColor
            )
        }
    }
}

@Composable
fun DrawingSurveyHud(
    toolMode: MapToolMode,
    draftPoints: List<GeoCoord>,
    onUndo: () -> Unit,
    onClear: () -> Unit,
    onSave: () -> Unit,
    modifier: Modifier = Modifier
) {
    val distanceText = if (toolMode == MapToolMode.DRAW_LINE || toolMode == MapToolMode.DRAW_POLYGON) {
        GeoUtils.formatDistance(GeoUtils.calculatePathLengthMeters(draftPoints))
    } else ""

    val areaText = if (toolMode == MapToolMode.DRAW_POLYGON && draftPoints.size >= 3) {
        GeoUtils.formatArea(GeoUtils.calculatePolygonAreaSqMeters(draftPoints))
    } else ""

    Card(
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = when (toolMode) {
                        MapToolMode.ADD_WAYPOINT -> "Tap map to set Waypoint position"
                        MapToolMode.DRAW_LINE -> "Tap map to add points along path (${draftPoints.size} pts)"
                        MapToolMode.DRAW_POLYGON -> "Tap map to set polygon vertices (${draftPoints.size} pts)"
                        else -> ""
                    },
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Row {
                    IconButton(onClick = onUndo, enabled = draftPoints.isNotEmpty()) {
                        Icon(imageVector = Icons.Default.Undo, contentDescription = "Undo Point")
                    }
                    IconButton(onClick = onClear, enabled = draftPoints.isNotEmpty()) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear Points")
                    }
                }
            }

            if (distanceText.isNotBlank()) {
                Text(
                    text = "Path Distance: $distanceText",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

            if (areaText.isNotBlank()) {
                Text(
                    text = "Enclosed Area: $areaText",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.tertiary
                )
            }

            Button(
                onClick = onSave,
                enabled = when (toolMode) {
                    MapToolMode.ADD_WAYPOINT -> draftPoints.isNotEmpty()
                    MapToolMode.DRAW_LINE -> draftPoints.size >= 2
                    MapToolMode.DRAW_POLYGON -> draftPoints.size >= 3
                    else -> false
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Save Feature to Database")
            }
        }
    }
}

@Composable
fun GpsStatusChip(
    gpsStatus: GpsStatusInfo,
    onClick: () -> Unit
) {
    val activeColor = if (gpsStatus.isGpsActive) Color(0xFF2E7D32) else Color(0xFFE65100)
    val bgColor = if (gpsStatus.isGpsActive) Color(0xFFE8F5E9) else Color(0xFFFFF3E0)
    val icon = if (gpsStatus.isGpsActive) Icons.Default.GpsFixed else Icons.Default.GpsNotFixed

    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = bgColor,
        border = BorderStroke(1.dp, activeColor.copy(alpha = 0.6f)),
        modifier = Modifier.padding(horizontal = 2.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(activeColor, CircleShape)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = icon,
                contentDescription = "GPS Active",
                tint = activeColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = if (gpsStatus.isGpsActive) "GPS ±${String.format("%.0f", gpsStatus.accuracyMeters)}m" else "GPS Searching",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = activeColor
            )
        }
    }
}

@Composable
fun GpsStatusDialog(
    gpsStatus: GpsStatusInfo,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.GpsFixed,
                contentDescription = null,
                tint = if (gpsStatus.isGpsActive) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                text = "Google GPS Hardware Status",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (gpsStatus.isGpsActive) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .background(if (gpsStatus.isGpsActive) Color(0xFF2E7D32) else Color(0xFFD32F2F), CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (gpsStatus.isGpsActive) "✓ GPS Active & Satellite Fix Acquired" else "⚠ Searching for GPS satellite signal...",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (gpsStatus.isGpsActive) Color(0xFF2E7D32) else Color(0xFFD32F2F)
                        )
                    }
                }

                HorizontalDivider()

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Location Engine:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Text(gpsStatus.provider, style = MaterialTheme.typography.bodyMedium)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Signal Accuracy:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Text("±${String.format("%.1f", gpsStatus.accuracyMeters)} meters", style = MaterialTheme.typography.bodyMedium)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Movement Speed:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Text("${String.format("%.1f", gpsStatus.speedKmh)} km/h", style = MaterialTheme.typography.bodyMedium)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Altitude (Elevation):", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Text("${String.format("%.1f", gpsStatus.altitude)} m MSL", style = MaterialTheme.typography.bodyMedium)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("GPS Coordinates:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Text("${String.format("%.5f", gpsStatus.lat)}, ${String.format("%.5f", gpsStatus.lon)}", style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", fontWeight = FontWeight.Bold)
            }
        }
    )
}
