package com.example.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.data.FeatureType
import com.example.data.GisFeature
import com.example.data.WmsLayer
import com.example.map.BaseMapTileSources
import com.example.map.BaseMapType
import com.example.map.WmsTileSource
import com.example.util.GeoCoord
import com.example.util.GeoUtils
import com.example.util.GeoUtils.toGeoPoints
import com.example.util.GpsStatusInfo
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.FolderOverlay
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay

@Composable
fun MapViewContainer(
    selectedBaseMap: BaseMapType,
    wmsLayers: List<WmsLayer>,
    gisFeatures: List<GisFeature>,
    toolMode: MapToolMode,
    draftPoints: List<GeoCoord>,
    userLocation: GeoCoord?,
    selectedFeature: GisFeature?,
    centerOnUserTrigger: Long,
    searchTargetLocation: GeoCoord? = null,
    searchTargetTrigger: Long = 0L,
    zoomInTrigger: Long = 0L,
    zoomOutTrigger: Long = 0L,
    gpsStatus: GpsStatusInfo = GpsStatusInfo(),
    onMapClick: (GeoCoord) -> Unit,
    onFeatureSelect: (GisFeature?) -> Unit,
    onUserLocationUpdate: (GeoCoord) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Initialize Osmdroid Configuration
    remember {
        Configuration.getInstance().load(context, context.getSharedPreferences("osmdroid_gis", android.content.Context.MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = context.packageName
    }

    val mapView = remember {
        MapView(context).apply {
            setMultiTouchControls(true)
            minZoomLevel = 3.0
            maxZoomLevel = 22.0
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            controller.setZoom(14.0)
            controller.setCenter(GeoPoint(10.0, 76.25)) // Centered over South India / Kerala
        }
    }

    // Set Base Map
    LaunchedEffect(selectedBaseMap) {
        val source = BaseMapTileSources.getTileSource(selectedBaseMap)
        mapView.setTileSource(source)
        mapView.invalidate()
    }

    // Center camera on user location when requested
    LaunchedEffect(centerOnUserTrigger) {
        if (centerOnUserTrigger > 0L && userLocation != null) {
            mapView.controller.animateTo(GeoPoint(userLocation.lat, userLocation.lon), 17.5, 1000L)
        }
    }

    // Center camera on search target location when requested
    LaunchedEffect(searchTargetTrigger) {
        if (searchTargetTrigger > 0L && searchTargetLocation != null) {
            mapView.controller.animateTo(GeoPoint(searchTargetLocation.lat, searchTargetLocation.lon), 16.5, 1000L)
        }
    }

    // Zoom In Trigger
    LaunchedEffect(zoomInTrigger) {
        if (zoomInTrigger > 0L) {
            mapView.controller.zoomIn()
        }
    }

    // Zoom Out Trigger
    LaunchedEffect(zoomOutTrigger) {
        if (zoomOutTrigger > 0L) {
            mapView.controller.zoomOut()
        }
    }

    val wmsFolderOverlay = remember { FolderOverlay().apply { name = "WMS Folder" } }
    val featuresFolderOverlay = remember { FolderOverlay().apply { name = "Features Folder" } }
    val locationFolderOverlay = remember { FolderOverlay().apply { name = "Location Folder" } }

    val mapEventsOverlay = remember {
        MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint?): Boolean {
                if (p != null) {
                    onMapClick(GeoCoord(p.latitude, p.longitude, p.altitude))
                }
                return true
            }

            override fun longPressHelper(p: GeoPoint?): Boolean {
                if (p != null) {
                    onMapClick(GeoCoord(p.latitude, p.longitude, p.altitude))
                }
                return true
            }
        })
    }

    LaunchedEffect(Unit) {
        if (!mapView.overlays.contains(mapEventsOverlay)) mapView.overlays.add(0, mapEventsOverlay)
        if (!mapView.overlays.contains(wmsFolderOverlay)) mapView.overlays.add(wmsFolderOverlay)
        if (!mapView.overlays.contains(featuresFolderOverlay)) mapView.overlays.add(featuresFolderOverlay)
        if (!mapView.overlays.contains(locationFolderOverlay)) mapView.overlays.add(locationFolderOverlay)
    }

    // 1. Update WMS Tile Overlays (Only runs when WMS layer list or visibility changes)
    LaunchedEffect(wmsLayers) {
        wmsFolderOverlay.items.clear()
        wmsLayers.filter { it.isVisible }.forEach { layer ->
            try {
                val wmsSource = WmsTileSource(layer)
                val wmsTileProvider = org.osmdroid.tileprovider.MapTileProviderBasic(context, wmsSource)
                val tilesOverlay = TilesOverlay(wmsTileProvider, context).apply {
                    setLoadingBackgroundColor(AndroidColor.TRANSPARENT)
                    setLoadingLineColor(AndroidColor.TRANSPARENT)
                    val alpha = (layer.opacity * 255).toInt().coerceIn(0, 255)
                    setColorFilter(PorterDuffColorFilter(AndroidColor.argb(alpha, 255, 255, 255), PorterDuff.Mode.MULTIPLY))
                }
                wmsFolderOverlay.add(tilesOverlay)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        mapView.invalidate()
    }

    // 2. Update Saved GIS Features & Draft Shapes
    LaunchedEffect(gisFeatures, draftPoints, selectedFeature, toolMode) {
        featuresFolderOverlay.items.clear()

        gisFeatures.forEach { feature ->
            val points = GeoUtils.pointsFromJson(feature.pointsJson)
            val colorInt = parseColorHex(feature.colorHex)
            val isSelected = selectedFeature?.id == feature.id

            when (feature.featureType) {
                FeatureType.WAYPOINT -> {
                    if (points.isNotEmpty()) {
                        val marker = Marker(mapView).apply {
                            position = GeoPoint(points[0].lat, points[0].lon)
                            title = feature.title
                            snippet = feature.description
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                            setOnMarkerClickListener { _, _ ->
                                onFeatureSelect(feature)
                                true
                            }
                        }
                        featuresFolderOverlay.add(marker)
                    }
                }

                FeatureType.LINE -> {
                    if (points.size >= 2) {
                        val polyline = Polyline(mapView).apply {
                            setPoints(points.toGeoPoints())
                            outlinePaint.color = if (isSelected) AndroidColor.YELLOW else colorInt
                            outlinePaint.strokeWidth = if (isSelected) 8.0f else 5.0f
                            outlinePaint.strokeCap = Paint.Cap.ROUND
                            setOnClickListener { _, _, _ ->
                                onFeatureSelect(feature)
                                true
                            }
                        }
                        featuresFolderOverlay.add(polyline)
                    }
                }

                FeatureType.POLYGON -> {
                    if (points.size >= 3) {
                        val polygon = Polygon(mapView).apply {
                            setPoints(points.toGeoPoints())
                            fillPaint.color = colorWithAlpha(colorInt, if (isSelected) 0.6f else feature.fillAlpha)
                            outlinePaint.color = if (isSelected) AndroidColor.YELLOW else colorInt
                            outlinePaint.strokeWidth = if (isSelected) 6.0f else 3.0f
                            setOnClickListener { _, _, _ ->
                                onFeatureSelect(feature)
                                true
                            }
                        }
                        featuresFolderOverlay.add(polygon)
                    }
                }
            }
        }

        // Render Draft Shape while user is drawing/surveying
        if (draftPoints.isNotEmpty()) {
            val draftGeoPoints = draftPoints.toGeoPoints()

            when (toolMode) {
                MapToolMode.ADD_WAYPOINT -> {
                    val lastPt = draftGeoPoints.last()
                    val draftMarker = Marker(mapView).apply {
                        position = lastPt
                        title = "Draft Waypoint"
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    }
                    featuresFolderOverlay.add(draftMarker)
                }

                MapToolMode.DRAW_LINE -> {
                    draftGeoPoints.forEach { pt ->
                        val ptMarker = Marker(mapView).apply {
                            position = pt
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                            icon = ContextCompat.getDrawable(context, android.R.drawable.presence_online)
                        }
                        featuresFolderOverlay.add(ptMarker)
                    }

                    if (draftGeoPoints.size >= 2) {
                        val draftPolyline = Polyline(mapView).apply {
                            setPoints(draftGeoPoints)
                            outlinePaint.color = AndroidColor.RED
                            outlinePaint.strokeWidth = 6.0f
                        }
                        featuresFolderOverlay.add(draftPolyline)
                    }
                }

                MapToolMode.DRAW_POLYGON -> {
                    draftGeoPoints.forEach { pt ->
                        val ptMarker = Marker(mapView).apply {
                            position = pt
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                            icon = ContextCompat.getDrawable(context, android.R.drawable.presence_online)
                        }
                        featuresFolderOverlay.add(ptMarker)
                    }

                    if (draftGeoPoints.size >= 3) {
                        val draftPolygon = Polygon(mapView).apply {
                            setPoints(draftGeoPoints)
                            fillPaint.color = colorWithAlpha(AndroidColor.RED, 0.35f)
                            outlinePaint.color = AndroidColor.RED
                            outlinePaint.strokeWidth = 5.0f
                        }
                        featuresFolderOverlay.add(draftPolygon)
                    } else if (draftGeoPoints.size == 2) {
                        val draftPolyline = Polyline(mapView).apply {
                            setPoints(draftGeoPoints)
                            outlinePaint.color = AndroidColor.RED
                            outlinePaint.strokeWidth = 5.0f
                        }
                        featuresFolderOverlay.add(draftPolyline)
                    }
                }

                else -> {}
            }
        }

        mapView.invalidate()
    }

    // 3. Update Live GPS Location Blue Dot, Accuracy Circle & Search Pin
    LaunchedEffect(userLocation, gpsStatus, searchTargetLocation) {
        locationFolderOverlay.items.clear()

        // Search Target Location Pin
        if (searchTargetLocation != null) {
            val searchMarker = Marker(mapView).apply {
                position = GeoPoint(searchTargetLocation.lat, searchTargetLocation.lon)
                title = "Searched Location"
                snippet = "GPS: ${String.format("%.5f", searchTargetLocation.lat)}, ${String.format("%.5f", searchTargetLocation.lon)}"
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            }
            locationFolderOverlay.add(searchMarker)
        }

        if (userLocation != null) {
            val userGeo = GeoPoint(userLocation.lat, userLocation.lon)

            val accuracyRadius = if (gpsStatus.accuracyMeters > 0f) gpsStatus.accuracyMeters.toDouble().coerceAtLeast(8.0) else 15.0
            val circlePoints = GeoUtils.createCirclePoints(userLocation, accuracyRadius)
            val accuracyPolygon = Polygon(mapView).apply {
                setPoints(circlePoints.toGeoPoints())
                fillPaint.color = AndroidColor.parseColor("#251A73E8") // Soft blue fill
                outlinePaint.color = AndroidColor.parseColor("#801A73E8") // Blue outline
                outlinePaint.strokeWidth = 3.0f
            }
            locationFolderOverlay.add(accuracyPolygon)

            val blueDotMarker = Marker(mapView).apply {
                position = userGeo
                title = "My Live GPS Location"
                snippet = "Accurate Point: ${String.format("%.6f", userLocation.lat)}, ${String.format("%.6f", userLocation.lon)}"
                icon = createBlueDotDrawable(context)
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            }
            locationFolderOverlay.add(blueDotMarker)
        }

        mapView.invalidate()
    }

    AndroidView(
        factory = { mapView },
        modifier = modifier.fillMaxSize()
    )
}

private fun createBlueDotDrawable(context: android.content.Context): Drawable {
    val density = context.resources.displayMetrics.density
    val sizePx = (24 * density).toInt()
    val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    // Outer white halo ring
    val whitePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AndroidColor.WHITE
        style = Paint.Style.FILL
    }
    canvas.drawCircle(sizePx / 2f, sizePx / 2f, sizePx / 2f, whitePaint)

    // Inner bright blue dot (#1A73E8)
    val bluePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AndroidColor.parseColor("#1A73E8")
        style = Paint.Style.FILL
    }
    canvas.drawCircle(sizePx / 2f, sizePx / 2f, (sizePx / 2f) - (3.5f * density), bluePaint)

    return BitmapDrawable(context.resources, bitmap)
}

private fun parseColorHex(hex: String): Int {
    return try {
        AndroidColor.parseColor(hex)
    } catch (e: Exception) {
        AndroidColor.BLUE
    }
}

private fun colorWithAlpha(color: Int, alphaFloat: Float): Int {
    val a = (alphaFloat * 255).toInt().coerceIn(0, 255)
    val r = AndroidColor.red(color)
    val g = AndroidColor.green(color)
    val b = AndroidColor.blue(color)
    return AndroidColor.argb(a, r, g, b)
}
