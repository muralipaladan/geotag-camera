package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.util.GeoCoord
import com.example.util.GeoUtils

@Composable
fun SaveFeatureDialog(
    toolMode: MapToolMode,
    draftPoints: List<GeoCoord>,
    onSave: (title: String, description: String, category: String, colorHex: String) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Survey Point") }

    val defaultColors = listOf(
        "#FF2196F3", // Blue
        "#FF4CAF50", // Green
        "#FFFF9800", // Orange
        "#FFE91E63", // Pink
        "#FF9C27B0", // Purple
        "#FF00BCD4", // Cyan
        "#FFFFEB3B"  // Yellow
    )
    var selectedColorHex by remember { mutableStateOf(defaultColors[0]) }

    val featureTypeName = when (toolMode) {
        MapToolMode.ADD_WAYPOINT -> "Waypoint / Marker"
        MapToolMode.DRAW_LINE -> "Line / Track"
        MapToolMode.DRAW_POLYGON -> "Polygon Boundary"
        else -> "GIS Feature"
    }

    val measurementSummary = when (toolMode) {
        MapToolMode.DRAW_LINE -> "Total Distance: " + GeoUtils.formatDistance(GeoUtils.calculatePathLengthMeters(draftPoints))
        MapToolMode.DRAW_POLYGON -> "Total Area: " + GeoUtils.formatArea(GeoUtils.calculatePolygonAreaSqMeters(draftPoints))
        MapToolMode.ADD_WAYPOINT -> if (draftPoints.isNotEmpty()) "Lat: ${String.format("%.5f", draftPoints[0].lat)}, Lon: ${String.format("%.5f", draftPoints[0].lon)}" else ""
        else -> ""
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Save $featureTypeName",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (measurementSummary.isNotBlank()) {
                    Text(
                        text = measurementSummary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title *") },
                    placeholder = { Text("e.g. Plot Boundary #102") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category / Tag") },
                    placeholder = { Text("e.g. Survey, Forest, Waterway") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Notes / Description") },
                    placeholder = { Text("Add survey remarks or coordinates notes...") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Feature Color:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    defaultColors.forEach { hex ->
                        val isSelected = hex == selectedColorHex
                        val parsedColor = try {
                            Color(android.graphics.Color.parseColor(hex))
                        } catch (e: Exception) {
                            Color.Blue
                        }

                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(parsedColor)
                                .border(
                                    width = if (isSelected) 3.dp else 0.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { selectedColorHex = hex }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(title, description, category, selectedColorHex)
                }
            ) {
                Text("Save Feature")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
