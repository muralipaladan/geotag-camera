package com.example.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.SampleWmsServers
import com.example.data.WmsLayer

@Composable
fun WmsEditDialog(
    editingLayer: WmsLayer?,
    onSave: (name: String, url: String, layerName: String, style: String, opacity: Float) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember(editingLayer) { mutableStateOf(editingLayer?.name ?: "") }
    var url by remember(editingLayer) { mutableStateOf(editingLayer?.serverUrl ?: "") }
    var layerName by remember(editingLayer) { mutableStateOf(editingLayer?.layerName ?: "") }
    var style by remember(editingLayer) { mutableStateOf(editingLayer?.style ?: "") }
    var opacity by remember(editingLayer) { mutableFloatStateOf(editingLayer?.opacity ?: 0.8f) }

    var isError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (editingLayer != null) "Edit WMS Service" else "Connect New WMS URL",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Provide WMS URL and Layer Name from any GIS server (GeoServer, MapServer, ArcGIS, QGIS Cloud, Bhuvan, USGS, NOAA).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (editingLayer == null) {
                    Text(
                        text = "Quick Sample Presets:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        SampleWmsServers.presets.take(3).forEach { sample ->
                            SuggestionChip(
                                onClick = {
                                    name = sample.name
                                    url = sample.serverUrl
                                    layerName = sample.layerName
                                },
                                label = { Text(sample.name, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Service Title / Name") },
                    placeholder = { Text("e.g. ISRO Land Use Map") },
                    leadingIcon = { Icon(Icons.Default.Layers, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = url,
                    onValueChange = {
                        url = it
                        isError = false
                    },
                    label = { Text("WMS Endpoint Server URL *") },
                    placeholder = { Text("https://example.com/geoserver/wms") },
                    leadingIcon = { Icon(Icons.Default.Language, contentDescription = null) },
                    isError = isError,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = layerName,
                    onValueChange = {
                        layerName = it
                        isError = false
                    },
                    label = { Text("Layer Name / ID *") },
                    placeholder = { Text("e.g. 0 or lulc50k or radar_composite") },
                    leadingIcon = { Icon(Icons.Default.Info, contentDescription = null) },
                    isError = isError,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = style,
                    onValueChange = { style = it },
                    label = { Text("Style (Optional)") },
                    placeholder = { Text("default") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Layer Opacity: ${(opacity * 100).toInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.width(110.dp)
                    )
                    Slider(
                        value = opacity,
                        onValueChange = { opacity = it },
                        valueRange = 0.0f..1.0f,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (url.isBlank() || layerName.isBlank()) {
                        isError = true
                    } else {
                        onSave(name, url, layerName, style, opacity)
                    }
                }
            ) {
                Text("Save & Render")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
