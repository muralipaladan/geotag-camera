package com.example.util

import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.util.GeoPoint
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class GeoCoord(val lat: Double, val lon: Double, val altitude: Double = 0.0)

data class GpsStatusInfo(
    val isGpsActive: Boolean = false,
    val accuracyMeters: Float = 0f,
    val speedKmh: Float = 0f,
    val provider: String = "Google Fused GPS",
    val lat: Double = 0.0,
    val lon: Double = 0.0,
    val altitude: Double = 0.0,
    val lastFixTimestamp: Long = 0L
)

object GeoUtils {

    const val EARTH_RADIUS_METERS = 6371008.8

    fun calculateDistanceMeters(p1: GeoCoord, p2: GeoCoord): Double {
        val lat1Rad = Math.toRadians(p1.lat)
        val lat2Rad = Math.toRadians(p2.lat)
        val dLat = Math.toRadians(p2.lat - p1.lat)
        val dLon = Math.toRadians(p2.lon - p1.lon)

        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(lat1Rad) * cos(lat2Rad) * sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return EARTH_RADIUS_METERS * c
    }

    fun calculatePathLengthMeters(points: List<GeoCoord>): Double {
        if (points.size < 2) return 0.0
        var total = 0.0
        for (i in 0 until points.size - 1) {
            total += calculateDistanceMeters(points[i], points[i + 1])
        }
        return total
    }

    fun calculatePolygonAreaSqMeters(points: List<GeoCoord>): Double {
        if (points.size < 3) return 0.0
        var totalArea = 0.0
        val numPoints = points.size

        for (i in 0 until numPoints) {
            val p1 = points[i]
            val p2 = points[(i + 1) % numPoints]

            val p1LatRad = Math.toRadians(p1.lat)
            val p2LatRad = Math.toRadians(p2.lat)
            val dLonRad = Math.toRadians(p2.lon - p1.lon)

            totalArea += dLonRad * (2 + sin(p1LatRad) + sin(p2LatRad))
        }

        totalArea = totalArea * EARTH_RADIUS_METERS * EARTH_RADIUS_METERS / 2.0
        return kotlin.math.abs(totalArea)
    }

    fun createCirclePoints(center: GeoCoord, radiusMeters: Double, pointsCount: Int = 36): List<GeoCoord> {
        val points = mutableListOf<GeoCoord>()
        val latRad = Math.toRadians(center.lat)
        val lonRad = Math.toRadians(center.lon)
        val d = radiusMeters / EARTH_RADIUS_METERS

        for (i in 0 until pointsCount) {
            val bearing = 2 * PI * i / pointsCount
            val pointLat = kotlin.math.asin(
                sin(latRad) * cos(d) + cos(latRad) * sin(d) * cos(bearing)
            )
            val pointLon = lonRad + atan2(
                sin(bearing) * sin(d) * cos(latRad),
                cos(d) - sin(latRad) * sin(pointLat)
            )
            points.add(GeoCoord(Math.toDegrees(pointLat), Math.toDegrees(pointLon)))
        }
        return points
    }

    fun formatDistance(meters: Double): String {
        return if (meters >= 1000) {
            String.format("%.2f km (%.2f mi)", meters / 1000.0, meters / 1609.34)
        } else {
            String.format("%.1f m (%.1f ft)", meters, meters * 3.28084)
        }
    }

    fun formatArea(sqMeters: Double): String {
        val sqKm = sqMeters / 1_000_000.0
        val hectares = sqMeters / 10_000.0
        val acres = sqMeters / 4046.86

        return if (sqMeters >= 1_000_000) {
            String.format("%.2f km² (%.2f hectares / %.2f acres)", sqKm, hectares, acres)
        } else {
            String.format("%.1f m² (%.2f hectares / %.2f acres)", sqMeters, hectares, acres)
        }
    }

    fun pointsToJson(points: List<GeoCoord>): String {
        val jsonArray = JSONArray()
        for (p in points) {
            val obj = JSONObject()
            obj.put("lat", p.lat)
            obj.put("lon", p.lon)
            obj.put("alt", p.altitude)
            jsonArray.put(obj)
        }
        return jsonArray.toString()
    }

    fun pointsFromJson(jsonStr: String): List<GeoCoord> {
        val list = mutableListOf<GeoCoord>()
        if (jsonStr.isBlank()) return list
        try {
            val jsonArray = JSONArray(jsonStr)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val lat = obj.optDouble("lat", 0.0)
                val lon = obj.optDouble("lon", 0.0)
                val alt = obj.optDouble("alt", 0.0)
                list.add(GeoCoord(lat, lon, alt))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun List<GeoCoord>.toGeoPoints(): List<GeoPoint> {
        return map { GeoPoint(it.lat, it.lon, it.altitude) }
    }
}
